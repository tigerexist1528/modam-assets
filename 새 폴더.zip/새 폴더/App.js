import React, { useState, useEffect } from "react";
import "./styles.css";

// data.js에서 필요한 데이터들을 가져옵니다.
import {
  // 1. 핵심 아이템 DB
  loadGameData,
  WEAPON_DB,
  GEAR_DB,

  // 2. 내실/강화 데이터
  SKILL_DB,
  REINFORCE_DB,
  POLISH_DB,
  MAGIC_OPTS_BY_GROUP,
  ENCHANT_LIST_BY_SLOT,
  EMBLEM_RULES,
  EMBLEM_DB,
  TRAINING_DB,
  AVATAR_DB,
  WEAPON_AVATAR_DB,
  SKILL_RUNE_DB,
  RUNE_CONSTANTS,
  GEAR_POINT_BONUS_DB,
  // 3. 유틸리티 및 리소스
  GET_ITEM_ICON,
  JOB_ILLUST,
  JOB_PASSIVES,
  UNIQUE_OPT_DESC,
  PLACEHOLDER_IMG,
  GET_JOB_ICON,
} from "./data";

// -----------------------------------------------------------------------------
// [1] Helper Functions & Constants (UI 및 로직용 상수)
// -----------------------------------------------------------------------------

const IMAGE_BASE_URL =
  "https://raw.githubusercontent.com/tigerexist1528/modam-assets/main/images";

const SLOT_ENG_NAMES = {
  무기: "weapon",
  머리어깨: "headshoulder",
  상의: "top",
  하의: "bottom",
  벨트: "belt",
  신발: "shoes",
  팔찌: "bracelet",
  목걸이: "necklace",
  반지: "ring",
  보조장비: "sub",
  마법석: "magicstone",
  귀걸이: "earring",
  오라: "aura",
  칭호: "title",
  크리쳐: "creature",
  아티팩트: "artifact",
};

// ★ [NEW] App.js 내부에서 안전하게 아이콘 가져오는 함수
const GET_ITEM_ICON_LOCAL = (name, slot) => {
  if (!name || !slot) return PLACEHOLDER_IMG;

  // 이름 정제 (접두사 제거)
  let cleanName = name;
  if (name.includes(":")) {
    cleanName = name.split(":")[1].trim();
  }

  // 폴더명 찾기
  const folder = SLOT_ENG_NAMES[slot] || "etc";

  return `${IMAGE_BASE_URL}/items/${folder}/${cleanName}.png`;
};

// 등급별 색상 반환
const getGradeColor = (grade = "") => {
  if (grade.includes("익시드")) return "var(--grade-exceed)";
  if (grade.includes("에픽")) return "var(--grade-epic)";
  if (grade.includes("유니크")) return "var(--grade-unique)";
  if (grade.includes("레어")) return "var(--grade-rare)";
  return "#fff";
};

// 옵션 등급별 색상 반환
const getOptionTierClass = (name) => {
  if (
    !name ||
    name.includes("선택 안함") ||
    name.includes("없음") ||
    name.includes("미설정")
  )
    return "color-none";
  if (name.includes("종결")) return "color-bis";
  if (name.includes("준종결")) return "color-high";
  return "color-mid";
};

// ★ [수정됨] 세트 옵션 요약 헬퍼 (풀워딩 & 하위 옵션 지원)
const getSetOptionSummary = (stats) => {
  if (!stats) return { text: "", isLowTier: false };

  const opts = [];

  // 1. 주요 증뎀 옵션
  if (stats.dmgInc) opts.push(`데미지+${stats.dmgInc}%`);
  if (stats.critDmgInc) opts.push(`크리티컬 데미지+${stats.critDmgInc}%`);
  if (stats.addDmg) opts.push(`추가 데미지+${stats.addDmg}%`);
  if (stats.skillAtkInc) opts.push(`스킬 공격력+${stats.skillAtkInc}%`);
  if (stats.allTypeDmg) opts.push(`모든 타입 피해+${stats.allTypeDmg}%`);
  if (stats.finalDmg) opts.push(`최종 데미지+${stats.finalDmg}%`);

  // 속성 강화 (4속성 동일 시 모속강)
  const { fireEle, waterEle, lightEle, darkEle } = stats;
  if (
    fireEle > 0 &&
    fireEle === waterEle &&
    fireEle === lightEle &&
    fireEle === darkEle
  ) {
    opts.push(`모든 속성 강화 +${fireEle}`);
  } else {
    if (fireEle > 0) opts.push(`화속성 강화 +${fireEle}`);
    if (waterEle > 0) opts.push(`수속성 강화 +${waterEle}`);
    if (lightEle > 0) opts.push(`명속성 강화 +${lightEle}`);
    if (darkEle > 0) opts.push(`암속성 강화 +${darkEle}`);
  }

  // 3. 스킬 레벨링 (연속 구간 찾기)
  if (stats.skill && stats.skill.lv) {
    const lvObj = stats.skill.lv;
    const levels = [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 65, 70, 75, 80];
    let minLv = null;
    let maxLv = null;
    let val = 0;

    // 구간 찾기
    levels.forEach((lv) => {
      const v = lvObj[`lv${lv}`];
      if (v > 0) {
        if (minLv === null) minLv = lv;
        maxLv = lv;
        val = v;
      }
    });

    if (minLv !== null && val > 0) {
      if (minLv === maxLv) opts.push(`${minLv}레벨 스킬 Lv+${val}`);
      else opts.push(`${minLv}~${maxLv}레벨 스킬 Lv+${val}`);
    }
  }

  // 4. 스탯 %
  if (stats.physAtkInc) opts.push(`물리 공격력+${stats.physAtkInc}%`);
  if (stats.magAtkInc) opts.push(`마법 공격력+${stats.magAtkInc}%`);
  if (stats.strInc) opts.push(`힘+${stats.strInc}%`);
  if (stats.intInc) opts.push(`지능+${stats.intInc}%`);

  // ★ 만약 핵심 옵션이 하나라도 있다면 -> High Tier 반환
  if (opts.length > 0) {
    return { text: opts.join(", "), isLowTier: false };
  }

  // --- [2] 하위/기초 옵션 (Fallback) ---
  // 핵심 옵션이 없을 때만 표시
  const minorOpts = [];
  if (stats.physAtk) minorOpts.push(`물리 공격력+${stats.physAtk}`);
  if (stats.magAtk) minorOpts.push(`마법 공격력+${stats.magAtk}`);
  if (stats.str) minorOpts.push(`힘+${stats.str}`);
  if (stats.int) minorOpts.push(`지능+${stats.int}`);

  if (minorOpts.length > 0) {
    return { text: minorOpts.join(", "), isLowTier: true }; // 분홍색 표시용 플래그
  }

  return { text: "", isLowTier: false };
};

// 장비 슬롯 정의
const EQUIP_SLOTS = [
  "무기",
  "머리어깨",
  "상의",
  "하의",
  "벨트",
  "신발",
  "팔찌",
  "목걸이",
  "반지",
  "보조장비",
  "마법석",
  "귀걸이",
  "오라",
  "칭호",
  "크리쳐",
  "아티팩트",
];
const EXCEED_SLOTS = ["상의", "팔찌", "귀걸이"];
const SPECIAL_SLOTS = ["오라", "칭호", "크리쳐", "아티팩트"];

// 직업 구조 데이터
const JOB_STRUCTURE = {
  "귀검사(남)": ["웨펀마스터", "소울브링어", "버서커", "아수라"],
  "귀검사(여)": [
    "소드마스터",
    "다크템플러",
    "데몬슬레이어",
    "베가본드",
    "블레이드",
  ],
  격투가: ["넨마스터", "스트라이커", "스트리트파이터", "그래플러"],
  "거너(남)": ["레인저(남)", "런처(남)", "메카닉(남)", "스핏파이어(남)"],
  "거너(여)": ["레인저(여)", "런처(여)", "메카닉(여)", "스핏파이어(여)"],
  마법사: ["엘레멘탈마스터", "배틀메이지", "마도학자", "인챈트리스"],
  "프리스트(남)": ["크루세이더(남)", "인파이터(남)"],
  "프리스트(여)": [
    "크루세이더(여)",
    "이단심판관",
    "무녀",
    "미스트리스",
    "인파이터(여)",
  ],
  워리어: ["와일드베인", "윈드시어"],
  도적: ["로그", "쿠노이치"],
  마창사: ["뱅가드", "다크랜서"],
};

// 무기 타입 데이터
const WEAPON_TYPES = {
  "귀검사(남)": ["소검", "도", "둔기", "대검", "광검"],
  "귀검사(여)": ["소검", "도", "둔기", "대검", "광검"],
  격투가: ["너클", "건틀릿", "클로", "권투글러브", "통파"],
  "거너(남)": ["리볼버", "자동권총", "머스켓", "핸드캐넌", "보우건"],
  "거너(여)": ["리볼버", "자동권총", "머스켓", "핸드캐넌", "보우건"],
  마법사: ["창", "봉", "로드", "스태프", "빗자루"],
  "프리스트(남)": ["십자가", "염주", "토템", "낫", "배틀액스"],
  "프리스트(여)": ["십자가", "염주", "토템", "낫", "배틀액스"],
  워리어: ["락소드", "윙블레이드"],
  도적: ["단검", "쌍검", "차크라웨펀"],
  마창사: ["미늘창", "투창"],
};

// --- Initial State (초기값) ---
const initialState = {
  character: { baseJob: "", subJob: "", weaponType: "", level: 85 },
  equipment: EQUIP_SLOTS.reduce(
    (acc, cur) => ({
      ...acc,
      [cur]: { setName: "선택 안함", grade: "일반", itemId: 0 },
    }),
    {}
  ),
  reinforce: EQUIP_SLOTS.reduce((acc, cur) => ({ ...acc, [cur]: 0 }), {}),
  polish: { 무기: 0, 보조장비: 0 },
  magic_unique: EQUIP_SLOTS.reduce(
    (acc, cur) => ({ ...acc, [cur]: "선택 안함" }),
    {}
  ),
  magic_common: EQUIP_SLOTS.reduce(
    (acc, cur) => ({ ...acc, [cur]: "선택 안함" }),
    {}
  ),
  emblem: [...EQUIP_SLOTS, "칭호"].reduce(
    (acc, cur) => ({ ...acc, [cur]: { slots: [] } }),
    {}
  ),
  enchant: EQUIP_SLOTS.reduce(
    (acc, cur) => ({ ...acc, [cur]: "선택 안함" }),
    {}
  ),

  training: {
    concentrator: 0,
    hopae: 0,
    breakthrough: 0,
    sealMain: "",
    sealSub: "",
    masterContract: true,
  },

  // 스킬룬 (지난번 수정사항)
  skillRunes: {
    slots: Array(20).fill(null),
    special: { gaho: 0, jihe: 0, waegok: 0 }, // (구버전 호환용, 필요 없으면 삭제 가능)
    general: [], // (구버전 호환용)
  },

  avatarSettings: { set: "없음", weapon: "없음" },
  uniqueOptions: {
    무기: "선택 안함",
    상의: "선택 안함",
    팔찌: "선택 안함",
    귀걸이: "선택 안함",
  },

  // ★ 상세 스탯 (DB 구조와 일치)
  stats: {
    physAtk: 0,
    magAtk: 0,
    str: 0,
    int: 0,
    physAtkInc: 0,
    magAtkInc: 0,
    strInc: 0,
    intInc: 0,
    physCrit: 0,
    magCrit: 0,
    physCritRate: 0,
    magCritRate: 0,
    critDmgInc: 0,
    dmgInc: 0,
    addDmg: 0,
    counterDmgInc: 0,
    counterAddDmg: 0,
    skillAtkInc: 0,
    allTypeDmg: 0,
    finalDmg: 0,
    elInflict1: 0,
    elInflict2: 0,
    fireEle: 0,
    waterEle: 0,
    lightEle: 0,
    darkEle: 0,
    highestEleAddDmg: 0,
    fireAddDmg: 0,
    waterAddDmg: 0,
    lightAddDmg: 0,
    darkAddDmg: 0,
    skill: { dmg: {}, lv: {}, cdr: {} },
    status: {
      poisonDmg: 0,
      bleedDmg: 0,
      burnDmg: 0,
      shockDmg: 0,
      poisonInc: 0,
      bleedInc: 0,
      burnInc: 0,
      shockInc: 0,
    },
    hpMax: 0,
    mpMax: 0,
    spirit: 0,
    physDef: 0,
    magDef: 0,
    physDmgRed: 0,
    magDmgRed: 0,
    hit: 0,
    hitRate: 0,
    atkSpeed: 0,
    castSpeed: 0,
    moveSpeed: 0,
    fireRes: 0,
    waterRes: 0,
    lightRes: 0,
    darkRes: 0,
    evasion: 0,
    evasionRate: 0,
    superArmor: 0,
    gearPoint: 0,
    defShred: 0,
  },

  skill: {
    levels: {}, // { "SK_ID": 10 }
    tpLevels: {}, // { "SK_ID": 1 }
  },

  activeSetEffects: { armor: [], accessory: [], special: [] },
};

// 아이템 그룹화 헬퍼 (일반 장비용)
const getGroupedItems = (db, slot, weaponType = null) => {
  const map = new Map();
  db.forEach((item) => {
    if (item.slot !== slot) return;
    if (weaponType && item.type && item.type !== weaponType) return;

    const baseKey = item.stats?.itemCode1 || item.id;
    if (!map.has(baseKey)) map.set(baseKey, { baseItem: item, variants: [] });
    map.get(baseKey).variants.push(item);
  });

  const groups = Array.from(map.values()).map((g) => {
    g.variants.sort(
      (a, b) => (a.stats?.itemCode2 || 0) - (b.stats?.itemCode2 || 0)
    );
    g.baseItem = g.variants[0];
    return g;
  });

  // 정렬: setCode 오름차순 (도감 순서)
  return groups.sort(
    (a, b) =>
      (a.baseItem.stats?.setCode || 9999) - (b.baseItem.stats?.setCode || 9999)
  );
};

// 특수 아이템 그룹화 헬퍼 (오라/칭호 등)
const getSpecialSets = (db, slot) => {
  const map = new Map();
  db.forEach((item) => {
    if (item.slot !== slot) return;
    const setCode = item.stats?.setCode || 0;
    if (!map.has(setCode))
      map.set(setCode, { setCode, setName: item.setName, items: [] });
    map.get(setCode).items.push(item);
  });
  // 정렬: setCode 내림차순 (높은 등급 우선)
  return Array.from(map.values()).sort((a, b) => b.setCode - a.setCode);
};

// =========================================================
// [최적화] ItemCard 컴포넌트 분리 & Memoization
// 리스트가 아무리 길어도 렉이 걸리지 않게 만듭니다.
// =========================================================
const ItemCard = React.memo(
  ({ item, slot, onClick, isVariant = false, colorVar = "" }) => {
    // 1. 이름 및 등급 처리
    let cleanName = item.name;
    let label = "일반";
    let borderColor = colorVar || "var(--grade-epic)";
    let bgColor = "transparent";

    if (isVariant) {
      const rawGrade = item.grade || "";
      if (rawGrade.includes(":")) label = rawGrade.split(":")[1].trim();
      else if (rawGrade.includes("익시드")) label = "익시드";
      else if (rawGrade.includes("유니크")) label = "유니크";
      else if (rawGrade.includes("레어")) label = "레어";

      if (rawGrade.includes("익시드")) {
        borderColor = "var(--grade-exceed)";
        bgColor = "rgba(0, 255, 255, 0.08)";
      } else if (rawGrade.includes("유니크")) {
        borderColor = "var(--grade-unique)";
      } else if (rawGrade.includes("레어")) {
        borderColor = "var(--grade-rare)";
      }
    } else {
      cleanName = item.name.includes(":")
        ? item.name.split(":")[1].trim()
        : item.name;
      borderColor = getGradeColor(item.grade);
    }

    // 2. 렌더링 (칩 형태 vs 카드 형태)
    if (isVariant) {
      return (
        <button
          className="grade-chip"
          style={{ borderColor, color: borderColor, background: bgColor }}
          onClick={(e) => {
            e.stopPropagation();
            onClick(item);
          }}
        >
          {label}
        </button>
      );
    }

    return (
      <div className="item-card">
        <div className="card-thumb">
          <img
            src={GET_ITEM_ICON_LOCAL(item.name, slot)}
            alt=""
            onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
          />
        </div>
        <div className="card-info">
          <div className="card-set">{item.setName || "단일"}</div>
          <div className="card-name" style={{ color: borderColor }}>
            {cleanName}
          </div>
          <div className="grade-chips">
            {/* children으로 variant 버튼들을 받음 */}
            {item.children}
          </div>
        </div>
      </div>
    );
  },
  (prev, next) => prev.item.id === next.item.id
); // ID가 같으면 리렌더링 방지

// [App.js] StatSlider 컴포넌트 (UX 개선: 백스페이스 허용, 초과 시 흔들림)
const StatSlider = ({ value, max, onChange, onCancel, onApply }) => {
  const [isInputMode, setIsInputMode] = useState(false);
  const [localVal, setLocalVal] = useState("");
  const [isShaking, setIsShaking] = useState(false); // 흔들림 효과 상태

  // 입력 모드 진입
  const handleFocus = () => {
    setLocalVal(value === 0 ? "" : String(value));
    setIsInputMode(true);
  };

  // 입력 핸들러
  const handleInputChange = (e) => {
    const inputStr = e.target.value;

    // 1. 다 지웠을 때 (백스페이스 허용)
    if (inputStr === "") {
      setLocalVal("");
      // 부모에겐 0으로 알리지만, 입력창은 비워둠
      return;
    }

    const num = Number(inputStr);

    // 2. 숫자가 아니면 무시
    if (isNaN(num)) return;

    // 3. 최대값 초과 시 (흔들림 효과 & Max로 고정)
    if (num > max) {
      setLocalVal(String(max)); // 강제로 최대값 표시
      onChange(max); // 부모 업데이트

      // 흔들림 애니메이션 트리거
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 300); // 0.3초 후 해제
      return;
    }

    // 4. 정상 입력
    setLocalVal(inputStr);
    onChange(num);
  };

  // 포커스 해제 시 (비어있으면 0으로 채움)
  const handleBlur = () => {
    if (localVal === "") {
      setLocalVal("0");
      onChange(0);
    }
    setIsInputMode(false);
  };

  return (
    <div className="slider-container">
      {/* 숫자 표시 & 입력 박스 */}
      <div
        className={`slider-display-box ${isShaking ? "shake-box" : ""}`}
        onClick={handleFocus}
      >
        {isInputMode ? (
          <input
            autoFocus
            type="number"
            className="slider-val-input"
            value={localVal}
            onChange={handleInputChange}
            onBlur={handleBlur}
            placeholder="0"
          />
        ) : (
          <div className={`slider-val-text ${isShaking ? "shake-box" : ""}`}>
            {value}
          </div>
        )}
        <div style={{ color: "#666", fontSize: "0.8rem", marginTop: "5px" }}>
          클릭하여 직접 입력
        </div>
      </div>

      {/* 슬라이더 컨트롤 */}
      <div className="slider-control-row">
        <button className="slider-btn" onClick={() => onChange(0)}>
          MIN
        </button>
        <button
          className="slider-step-btn"
          onClick={() => onChange(Math.max(0, value - 1))}
        >
          －
        </button>
        <input
          type="range"
          className="custom-range"
          min="0"
          max={max}
          step="1"
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
        />
        <button
          className="slider-step-btn"
          onClick={() => onChange(Math.min(max, value + 1))}
        >
          ＋
        </button>
        <button className="slider-btn" onClick={() => onChange(max)}>
          MAX
        </button>
      </div>

      <div
        className="modal-footer-btns"
        style={{ width: "100%", marginTop: "20px" }}
      >
        <button className="action-btn btn-cancel" onClick={onCancel}>
          취소 (ESC)
        </button>
        <button className="action-btn btn-apply" onClick={onApply}>
          적용 (Enter)
        </button>
      </div>
    </div>
  );
};

// =============================================================================
// [2] Main Component: App
// =============================================================================
export default function App() {
  // --- State Declarations ---
  // 1. 로딩 상태 추가
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  // 2. 앱 시작 시 데이터 불러오기
  useEffect(() => {
    const init = async () => {
      const success = await loadGameData();
      if (success) {
        setIsDataLoaded(true); // 데이터 준비 끝! 렌더링 시작
      }
    };
    init();
  }, []);

  const [activePage, setActivePage] = useState("HOME");
  const [userStats, setUserStats] = useState(initialState);

  // UI Control States
  const [activeModal, setActiveModal] = useState({ type: null, slot: null });
  const [searchQuery, setSearchQuery] = useState("");
  const [weaponFilter, setWeaponFilter] = useState("");
  const [specialPickerStep, setSpecialPickerStep] = useState(0);
  const [selectedSpecialSet, setSelectedSpecialSet] = useState(null);
  // [NEW] 대장간 임시 수정용 버퍼 (취소 기능을 위함)
  const [editBuffer, setEditBuffer] = useState({});

  // Result States
  const [finalStats, setFinalStats] = useState({});
  const [finalDamageInfo, setFinalDamageInfo] = useState({
    normal: 0,
    status: 0,
    total: 0,
  });
  // ★ 수정: 초기값을 { armor: [], ... } 형태의 객체로 지정해야 합니다.
  const [activeSets, setActiveSets] = useState({
    armor: [],
    accessory: [],
    special: [],
  });
  const [totalGearPoint, setTotalGearPoint] = useState(0);
  const [isLevelShaking, setIsLevelShaking] = useState(false);

  // [Helper] 텍스트 포맷터: '[' 앞에서 줄바꿈 처리
  const formatTextWithLineBreak = (text) => {
    if (!text) return "";
    // 예: "3레어5상급 [공격속도]" -> ["3레어5상급", "공격속도]"]
    const parts = text.split("[");
    if (parts.length === 1) return text;

    return (
      <>
        {parts[0]}
        <br />
        <span style={{ fontSize: "0.85em", color: "#aaa" }}>[{parts[1]}</span>
      </>
    );
  };

  // [Helper] 스탯 코드 -> 한글 변환기
  const STAT_KOR_MAP = {
    // 1. 기초 스탯
    physAtk: "물리 공격력",
    magAtk: "마법 공격력",
    physAtkInc: "물리 공격력",
    magAtkInc: "마법 공격력",
    str: "힘",
    int: "지능",
    strInc: "힘",
    intInc: "지능",
    physCrit: "물리 크리티컬",
    magCrit: "마법 크리티컬",
    physCritRate: "물리 크리티컬",
    magCritRate: "마법 크리티컬",

    // 2. 공격력 관련
    critDmgInc: "크리티컬 데미지",
    dmgInc: "데미지",
    addDmg: "추가 데미지",
    counterDmgInc: "카운터 공격 시 데미지",
    counterAddDmg: "카운터 공격 시 추가 데미지",
    skillAtkInc: "스킬 공격력",
    allTypeDmg: "모든 타입 피해",
    finalDmg: "최종 데미지",

    // 3. 속성 강화
    elInflict1: "속성 부여",
    elInflict2: "속성 부여",
    fireEle: "화속성 강화",
    waterEle: "수속성 강화",
    lightEle: "명속성 강화",
    darkEle: "암속성 강화",
    allEle: "모든 속성 강화",
    highestEleAddDmg: "최고 속성 추가 데미지",
    fireAddDmg: "화속성 추가 데미지",
    waterAddDmg: "수속성 추가 데미지",
    lightAddDmg: "명속성 추가 데미지",
    darkAddDmg: "암속성 추가 데미지",

    // 4. 상태이상 관련
    bleedDmg: "공격 시 출혈 데미지",
    bleedInc: "출혈 데미지 증가",
    poisonDmg: "공격 시 중독 데미지",
    poisonInc: "중독 데미지 증가",
    burnDmg: "공격 시 화상 데미지",
    burnInc: "화상 데미지 증가",
    shockDmg: "공격 시 감전 데미지",
    shockInc: "감전 데미지 증가",

    // 5. 유틸 관련
    hpMax: "HP MAX",
    mpMax: "MP MAX",
    spirit: "정신력",
    physDef: "물리 방어력",
    magDef: "마법 방어력",
    physDmgRed: "물리 데미지 감소",
    magDmgRed: "마법 데미지 감소",
    hit: "적중",
    hitRate: "적중",
    atkSpeed: "공격 속도",
    castSpeed: "캐스팅 속도",
    moveSpeed: "이동 속도",
    fireRes: "화속성 저항",
    waterRes: "수속성 저항",
    lightRes: "명속성 저항",
    darkRes: "암속성 저항",
    evasion: "회피",
    evasionRate: "회피",
    superArmor: "슈퍼 아머",
    gearPoint: "장비 포인트",
    defShred: "방어력 감소",
  };

  // 스탯 객체를 한글 문자열로 변환하는 함수
  const formatStatsToKor = (stats) => {
    if (!stats || Object.keys(stats).length === 0) return "옵션 없음";

    return Object.entries(stats)
      .map(([key, val]) => {
        if (val === 0) return null;

        // 1-1. 속성 부여 (1:화, 2:수, 3:명, 4:암)
        if (key === "elInflict1" || key === "elInflict2") {
          const elMap = { 1: "화속성", 2: "수속성", 3: "명속성", 4: "암속성" };
          return elMap[val] ? `${elMap[val]} 부여` : null;
        }

        // 1-2. 슈퍼아머 (1:적용)
        if (key === "superArmor") {
          return val === 1 ? "슈퍼아머 부여" : null;
        }

        const label = STAT_KOR_MAP[key] || key; // 매핑 없으면 영어 키 그대로 표시

        // %가 붙어야 하는 옵션들 체크 (증뎀류, 속도류)
        const isPercent = [
          "physAtkInc",
          "magAtkInc",
          "strInc",
          "intInc",
          "physCritRate",
          "magCritRate",
          "critDmgInc",
          "dmgInc",
          "addDmg",
          "counterDmgInc",
          "counterAddDmg",
          "skillAtkInc",
          "allTypeDmg",
          "finalDmg",
          "highestEleAddDmg",
          "waterAddDmg",
          "lightAddDmg",
          "darkAddDmg",
          "poisonDmg",
          "bleedDmg",
          "burnDmg",
          "shockDmg",
          "poisonInc",
          "bleedInc",
          "burnInc",
          "shockInc",
          "physDmgRed",
          "magDmgRed",
          "hitRate",
          "atkSpeed",
          "castSpeed",
          "moveSpeed",
          "evasionRate",
          "defShred",
        ].includes(key);

        // B. 마이너스(-)로 표시해야 하는 스탯 목록 (예: 쿨감, 방깎)
        // (보통 게임에서 '쿨타임 감소 +10%'라고 쓰기도 하고 '쿨타임 -10%'라고 쓰기도 함. 취향껏 설정)
        const isNegative = [].includes(key);

        // 값 포맷팅
        // 예: +10, -10, +5.5
        let valStr = val;
        if (isNegative) {
          valStr = `-${val}`; // 강제 마이너스 부착
        } else {
          valStr = `+${val}`; // 기본 플러스 부착
        }

        return `${label} +${val}${isPercent ? "%" : ""}`;
      })
      .join(", ");
  };

  // --- Updater Functions ---
  const updateStat = (cat, key, val) => {
    setUserStats((prev) => ({ ...prev, [cat]: { ...prev[cat], [key]: val } }));
  };

  const handleGearUpdate = (slot, newItemId) => {
    setUserStats((prev) => {
      const next = { ...prev };
      const db = slot === "무기" ? WEAPON_DB : GEAR_DB;
      const item = db.find((i) => i.id === Number(newItemId));

      next.equipment[slot] = {
        itemId: Number(newItemId),
        setName: item ? item.setName : "선택 안함",
        grade: item ? item.grade : "일반",
      };
      // 익시드 부위 해제 시 고유옵션 초기화
      if (
        EXCEED_SLOTS.includes(slot) &&
        (!item || !item.grade.includes("익시드"))
      ) {
        next.uniqueOptions[slot] = "선택 안함";
      }
      return next;
    });
  };

  // =========================================================
  // [최적화] Aggressive Image Preloading (Priority Queue)
  // =========================================================
  useEffect(() => {
    // 우선순위 큐: 직업 아이콘 -> 내실 아이콘 -> 장비 아이콘 순서로 로딩
    const preloadQueue = async () => {
      const load = (src) => {
        return new Promise((resolve) => {
          const img = new Image();
          img.src = src;
          img.onload = resolve;
          img.onerror = resolve; // 에러나도 다음으로 진행
        });
      };

      // 1. [Critical] 직업/전직 아이콘 (즉시 로딩)
      const jobIcons = [];
      Object.keys(JOB_STRUCTURE).forEach((job) => {
        jobIcons.push(GET_JOB_ICON("job", job));
        JOB_STRUCTURE[job].forEach((subJob) =>
          jobIcons.push(GET_JOB_ICON("class", subJob))
        );
      });
      await Promise.all(jobIcons.map((src) => load(src)));

      // 2. [High] 내실 및 로고 (100ms 뒤 로딩)
      setTimeout(async () => {
        await load(PLACEHOLDER_IMG);
        // 필요한 경우 내실 관련 아이콘도 추가
      }, 100);

      // 3. [Medium] 장비 아이콘 (배경에서 천천히 로딩)
      // 장비는 많으므로 청크(Chunk) 단위로 끊어서 로딩하여 UI 블락 방지
      const allItems = [...GEAR_DB, ...WEAPON_DB];
      const CHUNK_SIZE = 20;

      const loadChunk = (index) => {
        if (index >= allItems.length) return;

        const chunk = allItems.slice(index, index + CHUNK_SIZE);
        chunk.forEach((item) => {
          const slotFolder = item.slot || "weapon";
          const src = GET_ITEM_ICON(item.name, slotFolder);
          // 이미지 객체만 생성해두면 브라우저가 캐싱함 (await 안 함)
          new Image().src = src;
        });

        // 다음 청크는 프레임 여유가 있을 때 실행
        if (window.requestIdleCallback) {
          window.requestIdleCallback(() => loadChunk(index + CHUNK_SIZE));
        } else {
          setTimeout(() => loadChunk(index + CHUNK_SIZE), 50);
        }
      };

      // 장비 로딩 시작 (약간 딜레이 후)
      setTimeout(() => loadChunk(0), 500);
    };

    preloadQueue();
  }, []);

  // =========================================================
  // [3] Calculation Engine (useEffect) - 핵심 로직
  // =========================================================
  useEffect(() => {
    const timer = setTimeout(() => {
      // -----------------------------------------------------------------
      // [Start] 계산 로직 시작
      // -----------------------------------------------------------------

      let nextStats = JSON.parse(JSON.stringify(initialState.stats));
      let totalSkillAtkRatio = 1.0;
      let totalAllTypeDmgRatio = 1.0;
      let totalFinalDmgRatio = 1.0;

      // [Helper] Stats Merger (스탯 합산 헬퍼)
      const mergeStats = (sourceStats) => {
        if (!sourceStats) return;
        Object.keys(sourceStats).forEach((key) => {
          const val = sourceStats[key];
          if (val === null || val === undefined) return;

          // 1. 곱연산 그룹
          if (key === "skillAtkInc") {
            if (val > 0) totalSkillAtkRatio *= 1 + val / 100;
            return;
          }
          if (key === "allTypeDmg") {
            if (val > 0) totalAllTypeDmgRatio *= 1 + val / 100;
            return;
          }
          if (key === "finalDmg") {
            if (val > 0) totalFinalDmgRatio *= 1 + val / 100;
            return;
          }

          // 2. 모속강 처리
          if (key === "allEle") {
            nextStats.fireEle = (nextStats.fireEle || 0) + val;
            nextStats.waterEle = (nextStats.waterEle || 0) + val;
            nextStats.lightEle = (nextStats.lightEle || 0) + val;
            nextStats.darkEle = (nextStats.darkEle || 0) + val;
            return;
          }

          // 3. 중첩 객체 (status, skill 등)
          if (typeof val === "object" && !Array.isArray(val)) {
            if (!nextStats[key]) nextStats[key] = {};
            Object.keys(val).forEach((subKey) => {
              if (typeof val[subKey] === "object") {
                if (!nextStats[key][subKey]) nextStats[key][subKey] = {};
                Object.keys(val[subKey]).forEach((deepKey) => {
                  nextStats[key][subKey][deepKey] =
                    (nextStats[key][subKey][deepKey] || 0) +
                    (val[subKey][deepKey] || 0);
                });
              } else {
                nextStats[key][subKey] =
                  (nextStats[key][subKey] || 0) + (val[subKey] || 0);
              }
            });
            return;
          }

          // 4. 속성 부여 (최대값 유지)
          if (key === "elInflict1" || key === "elInflict2") {
            nextStats[key] = Math.max(nextStats[key], val);
            return;
          }

          // 5. 기본 합연산
          if (typeof nextStats[key] === "number" && typeof val === "number") {
            nextStats[key] += val;
          }
        });
      };

      // -----------------------------------------------------------------
      // [0] 장비 스탯 합산 & 세트 데이터 수집 (수정된 로직)
      // -----------------------------------------------------------------
      const setStatusMap = {};

      EQUIP_SLOTS.forEach((slot) => {
        const eqInfo = userStats.equipment[slot];
        if (eqInfo.itemId === 0) return;

        // 무기/방어구 DB 구분
        const db = slot === "무기" ? WEAPON_DB : GEAR_DB;
        const item = db.find((i) => i.id === eqInfo.itemId);

        if (item && item.stats) {
          mergeStats(item.stats); // 기본 스탯 합산

          // 세트 카운팅 준비
          const code = item.stats.setCode;
          if (code) {
            if (!setStatusMap[code]) {
              // 세트 타입 추론 (방어구/악세/특장)
              let setType = "special";
              if (["머리어깨", "상의", "하의", "벨트", "신발"].includes(slot))
                setType = "armor";
              else if (["팔찌", "목걸이", "반지"].includes(slot))
                setType = "accessory";

              setStatusMap[code] = { total: 0, variants: {}, type: setType };
            }

            setStatusMap[code].total += 1;

            // 접두사("에픽 : 각오" 등) 판별
            if (item.grade && item.grade.includes(":")) {
              const variant = item.grade.split(":")[1].trim();
              setStatusMap[code].variants[variant] =
                (setStatusMap[code].variants[variant] || 0) + 1;
            }
          }
        }
      });

      // -----------------------------------------------------------------
      // [C] 세트 효과 로직 적용 (접두사 우선 법칙)
      // -----------------------------------------------------------------
      const nextActiveSets = { armor: [], accessory: [], special: [] };

      // DB에서 "3세트 효과" 또는 "5세트 효과" 아이템만 필터링
      const setEffectItems = GEAR_DB.filter(
        (item) => item.slot === "3세트 효과" || item.slot === "5세트 효과"
      );

      Object.keys(setStatusMap).forEach((code) => {
        const status = setStatusMap[code];
        // 현재 세트 코드에 해당하는 효과 아이템들
        const currentSetItems = setEffectItems.filter(
          (i) => i.stats.setCode == code
        );

        // 3세트, 5세트 순차 체크
        [3, 5].forEach((requiredCount) => {
          const candidates = currentSetItems.filter(
            (i) => i.slot === `${requiredCount}세트 효과`
          );
          if (candidates.length === 0) return;

          let appliedItem = null;

          // 1. 접두사 우선 체크 (예: 각오 3개 이상이면 각오 세트 적용)
          for (const [variant, count] of Object.entries(status.variants)) {
            if (count >= requiredCount) {
              const variantItem = candidates.find((i) =>
                i.grade.includes(variant)
              );
              if (variantItem) {
                appliedItem = variantItem;
                break;
              }
            }
          }

          // 2. 일반 체크 (접두사 충족 안 되면 일반 세트 적용)
          if (!appliedItem && status.total >= requiredCount) {
            appliedItem = candidates.find((i) => !i.grade.includes(":"));
          }

          // 3. 적용
          if (appliedItem) {
            mergeStats(appliedItem.stats);

            // 이름 파싱 ("각오: 메탈기어" -> prefix:"각오", name:"메탈기어")
            let displayName = appliedItem.name;
            let prefix = null;
            if (appliedItem.name.includes(":")) {
              const parts = appliedItem.name.split(":");
              prefix = parts[0].trim();
              displayName = parts[1].trim();
            }

            if (nextActiveSets[status.type]) {
              nextActiveSets[status.type].push({
                name: displayName,
                prefix: prefix,
                count: requiredCount,
              });
            }
          }
        });
      });

      // UI 업데이트 (세트 효과 목록)
      setActiveSets(nextActiveSets);

      // [D] 내실 합산 (강화/연마/마부/마봉)
      const getMagicSealGroup = (s) => {
        if (s === "무기") return "무기";
        if (["머리어깨", "상의", "하의", "벨트", "신발"].includes(s))
          return "방어구";
        if (["팔찌", "목걸이", "반지"].includes(s)) return "악세서리";
        if (["보조장비", "마법석", "귀걸이"].includes(s)) return "특수장비";
        return null;
      };

      // [D] 내실 합산 (강화/연마/마부/마봉/엠블렘)
      // ★ 중요: 모든 슬롯을 순회하며 합산합니다.
      EQUIP_SLOTS.forEach((slot) => {
        // 1. 강화
        const rLevel = userStats.reinforce[slot] || 0;
        if (rLevel > 0) {
          const rStats = REINFORCE_DB[slot]?.[rLevel];
          if (rStats) mergeStats(rStats);
        }
        // 2. 연마
        const pLevel = userStats.polish[slot] || 0;
        if (pLevel > 0) {
          const pStats = POLISH_DB[slot]?.[pLevel];
          if (pStats) mergeStats(pStats);
        }
        // 3. 마법부여
        const enchName = userStats.enchant[slot];
        if (enchName && enchName !== "선택 안함") {
          const list = ENCHANT_LIST_BY_SLOT[slot] || [];
          const target = list.find((e) => e.name === enchName);
          if (target && target.stats) mergeStats(target.stats);
        }
        // 4. 마법봉인
        const getMagicSealGroup = (s) => {
          if (s === "무기") return "무기";
          if (["머리어깨", "상의", "하의", "벨트", "신발"].includes(s))
            return "방어구";
          if (["팔찌", "목걸이", "반지"].includes(s)) return "악세서리";
          if (["보조장비", "마법석", "귀걸이"].includes(s)) return "특수장비";
          return null;
        };
        const mGroup = getMagicSealGroup(slot);
        if (mGroup && MAGIC_OPTS_BY_GROUP[mGroup]) {
          const uLabel = userStats.magic_unique[slot];
          const cLabel = userStats.magic_common[slot];
          const groupData = MAGIC_OPTS_BY_GROUP[mGroup];

          if (uLabel && uLabel !== "선택 안함") {
            const uOpt = groupData.unique.find((o) => o.label === uLabel);
            if (uOpt && uOpt.stats) mergeStats(uOpt.stats);
          }
          if (cLabel && cLabel !== "선택 안함") {
            const cOpt = groupData.common.find((o) => o.label === cLabel);
            if (cOpt && cOpt.stats) mergeStats(cOpt.stats);
          }
        }

        // ★ 5. 엠블렘 스탯 반영 (위치 수정 완료)
        // 이제 slot 변수가 정의된 이 반복문 안에서 실행되므로 에러가 나지 않습니다.
        const emblemData = userStats.emblem[slot];
        const emblemList = Array.isArray(emblemData)
          ? emblemData
          : emblemData
          ? [emblemData]
          : [];

        emblemList.forEach((emb) => {
          if (!emb || !emb.stats) return;
          mergeStats(emb.stats);
        });
      });

      // [E] 기타 내실 (수련/아바타/스킬룬)
      // training 데이터 안전하게 가져오기 (없으면 빈 객체)
      const {
        concentrator = 0,
        hopae = 0,
        breakthrough = 0,
        sealMain = "",
        sealSub = "",
      } = userStats.training || {};

      // ★ [수정] 단계별 누적 합산 로직 (1단계 ~ 현재단계 반복)

      // 1. 마력 응축기
      if (TRAINING_DB.concentrator) {
        for (let i = 1; i <= concentrator; i++) {
          // 해당 단계 데이터가 있으면 합산
          if (TRAINING_DB.concentrator[i]) {
            // 만약 DB 구조가 { stats: {...} } 형태라면 .stats를, 아니면 객체 자체를 넣으세요.
            // 기존 코드 문맥상 객체 자체를 넣는 것으로 추정됩니다.
            mergeStats(TRAINING_DB.concentrator[i]);
          }
        }
      }

      // 2. 호패
      if (TRAINING_DB.hopae) {
        for (let i = 1; i <= hopae; i++) {
          if (TRAINING_DB.hopae[i]) {
            mergeStats(TRAINING_DB.hopae[i]);
          }
        }
      }

      // 3. 돌파
      if (TRAINING_DB.breakthrough) {
        for (let i = 1; i <= breakthrough; i++) {
          if (TRAINING_DB.breakthrough[i]) {
            mergeStats(TRAINING_DB.breakthrough[i]);
          }
        }
      }

      // 4. 성안의 봉인 (기존 로직 유지)
      if (TRAINING_DB.castle_seal) {
        if (TRAINING_DB.castle_seal.base)
          mergeStats(TRAINING_DB.castle_seal.base);
        if (sealMain) {
          const csMain = TRAINING_DB.castle_seal.main.find(
            (o) => o.name === sealMain
          );
          if (csMain) mergeStats(csMain.stats);
        }
        if (sealSub) {
          const csSub = TRAINING_DB.castle_seal.sub.find(
            (o) => o.name === sealSub
          );
          if (csSub) mergeStats(csSub.stats);
        }
      }

      const avSet = userStats.avatarSettings.set;
      if (avSet && avSet !== "없음" && AVATAR_DB[avSet]) {
        mergeStats(AVATAR_DB[avSet]);
      }

      const { slots } = userStats.skillRunes;
      const { subJob } = userStats.character;

      // 1. 특수 룬 카운팅
      let gahoCount = 0;
      let jiheCount = 0;

      slots.forEach((rune) => {
        if (!rune) return;
        if (rune.id === "gaho") gahoCount++;
        if (rune.id === "jihe") jiheCount++;
        // 왜곡은 추후 구현
      });

      const isSynergy = RUNE_CONSTANTS.special.synergyJobs.includes(subJob);
      const threshold = isSynergy ? 1 : 2; // 시너지 직업은 1개, 그 외는 2개

      // 특수 룬 옵션 적용 (중복 적용 불가 - threshold 이상이면 1회만 적용)
      if (gahoCount >= threshold)
        mergeStats(RUNE_CONSTANTS.special.options.gaho);
      if (jiheCount >= threshold)
        mergeStats(RUNE_CONSTANTS.special.options.jihe);

      // 2. 일반 룬 (스킬별 복리 연산 준비)
      // 일반 룬은 '특정 레벨 스킬 공격력'을 올려주므로,
      // mergeStats(단순 합산)가 아니라 skill 객체에 별도로 누적해야 함.

      slots.forEach((rune) => {
        if (!rune || rune.type !== "general") return;

        // 예: 각성, 3레벨, 45제 -> 스증 3%
        const val = RUNE_CONSTANTS.general.values[rune.id][rune.grade];
        const lvKey = `lv${rune.level}`; // lv45

        // skill.dmg 객체가 없으면 생성
        if (!nextStats.skill.dmg) nextStats.skill.dmg = {};
        if (!nextStats.skill.dmg[lvKey]) nextStats.skill.dmg[lvKey] = 0;

        // ★ 핵심: 복리 계산을 위한 수치 누적 방식 고민
        // 룬의 스증은 "기존 스증에 곱연산" 되므로,
        // 여기서는 일단 단순 합산으로 저장하고, 나중에 데미지 계산식에서 (1 + 합산/100)으로 처리하거나
        // 혹은 여기서 바로 복리 계산된 계수를 저장할 수도 있습니다.
        // 개발자님의 요청: "해당 레벨 스킬만 다시 각각의 수치를 복리로 계산"
        // 즉, 룬이 3개라면 (1.03 * 1.03 * 1.03) 처럼 동작해야 함.

        // 따라서 단순 합산이 아니라, '복리 계수'를 관리하는 것이 맞음.
        // 하지만 현재 구조상 nextStats.skill.dmg는 단순 수치 저장이므로,
        // '룬에 의한 추가 스증 복리값'을 따로 관리하겠습니다.
      });

      // (복리 계산 로직은 데미지 계산식 쪽에 반영해야 함.
      // 현재 계산기 로직은 전체 데미지를 구하는 것이므로,
      // 개별 스킬 데미지 리스트를 뽑을 때 이 룬 데이터를 활용해야 합니다.
      // 일단 nextStats.skill.runes 라는 별도 공간에 룬 정보를 저장해두겠습니다.)

      nextStats.skill.runes = slots.filter((r) => r && r.type === "general");

      // [F] 장비 포인트(항마력) 그룹별 계산 및 보너스 적용
      let gpArmor = 0;
      let gpAcc = 0;
      let gpSpecial = 0;

      // 무기는 장비 포인트가 없으므로 계산에서 제외
      EQUIP_SLOTS.forEach((slot) => {
        if (slot === "무기") return; // 무기 패스

        const item = userStats.equipment[slot];
        if (!item || item.itemId === 0) return;

        const dbItem = GEAR_DB.find((i) => i.id === item.itemId);
        const point = dbItem?.stats?.gearPoint || 0;

        if (["머리어깨", "상의", "하의", "벨트", "신발"].includes(slot))
          gpArmor += point;
        else if (["팔찌", "목걸이", "반지"].includes(slot)) gpAcc += point;
        else if (["보조장비", "마법석", "귀걸이"].includes(slot))
          gpSpecial += point;
      });

      // UI 표시를 위해 총합 저장 (단순 참고용)
      nextStats.gearPoint = gpArmor + gpAcc + gpSpecial;
      // ★ 그룹별 점수도 stats에 저장하여 UI에서 활용
      nextStats.gpDetails = { armor: gpArmor, acc: gpAcc, special: gpSpecial };

      // 보너스 스탯 적용 헬퍼
      const applyGearPointBonus = (type, currentPoint) => {
        const thresholds = GEAR_POINT_BONUS_DB[type] || [];
        const sorted = [...thresholds].sort(
          (a, b) => b.threshold - a.threshold
        );
        // 달성한 단계 찾기 (내림차순 정렬했으므로 첫 번째로 걸리는 게 최고 단계)
        const bonus = sorted.find((tier) => currentPoint >= tier.threshold);

        if (bonus && bonus.stats) {
          // ★ 여기서 각각 mergeStats를 호출하므로, 곱연산 스탯(allTypeDmg 등)은
          // 자동으로 서로 곱해집니다. (1.05 * 1.05 ...)
          mergeStats(bonus.stats);
        }
      };

      applyGearPointBonus("armor", gpArmor);
      applyGearPointBonus("accessory", gpAcc);
      applyGearPointBonus("special", gpSpecial);

      // =================================================
      // [Final] 데미지 계산
      // =================================================
      const totalPhysAtkBase = nextStats.physAtk;
      const totalMagAtkBase = nextStats.magAtk;
      const totalStrBase = nextStats.str;
      const totalIntBase = nextStats.int;

      const finalPhysAtk = totalPhysAtkBase * (1 + nextStats.physAtkInc / 100);
      const finalMagAtk = totalMagAtkBase * (1 + nextStats.magAtkInc / 100);
      const finalStr = totalStrBase * (1 + nextStats.strInc / 100);
      const finalInt = totalIntBase * (1 + nextStats.intInc / 100);

      const mainStatVal = Math.max(finalStr, finalInt);
      const mainAtkVal = Math.max(finalPhysAtk, finalMagAtk);
      const statFactor = 1 + mainStatVal / 250;

      // 속성
      const fireVal = nextStats.fireEle;
      const waterVal = nextStats.waterEle;
      const lightVal = nextStats.lightEle;
      const darkVal = nextStats.darkEle;
      const inflictedElements = [];
      if (nextStats.elInflict1 > 0)
        inflictedElements.push(nextStats.elInflict1);
      if (nextStats.elInflict2 > 0)
        inflictedElements.push(nextStats.elInflict2);

      let maxEle = 0;
      if (inflictedElements.length === 0) maxEle = 0;
      else {
        let currentMax = -9999;
        if (inflictedElements.includes(1))
          currentMax = Math.max(currentMax, fireVal);
        if (inflictedElements.includes(2))
          currentMax = Math.max(currentMax, waterVal);
        if (inflictedElements.includes(3))
          currentMax = Math.max(currentMax, lightVal);
        if (inflictedElements.includes(4))
          currentMax = Math.max(currentMax, darkVal);
        maxEle = Math.max(0, currentMax);
      }
      const eleFactor = 1 + maxEle * 0.0045;

      // 크리티컬
      const critRatePct = Math.min(
        Math.max(nextStats.physCritRate, nextStats.magCritRate),
        100
      );
      const critDmgMult = 1.5 + nextStats.critDmgInc / 100;
      const critFactor =
        1 - critRatePct / 100 + (critRatePct / 100) * critDmgMult;

      // 증뎀/추뎀/스증
      const dmgIncFactor =
        1 + (nextStats.dmgInc + nextStats.counterDmgInc) / 100;

      let highestEleVal = Math.max(fireVal, waterVal, lightVal, darkVal);
      let finalHighestEleAdd =
        (nextStats.highestEleAddDmg / 100) * (1.05 + 0.0045 * highestEleVal);
      let fireAdd = (nextStats.fireAddDmg / 100) * (1.05 + 0.0045 * fireVal);
      let waterAdd = (nextStats.waterAddDmg / 100) * (1.05 + 0.0045 * waterVal);
      let lightAdd = (nextStats.lightAddDmg / 100) * (1.05 + 0.0045 * lightVal);
      let darkAdd = (nextStats.darkAddDmg / 100) * (1.05 + 0.0045 * darkVal);

      const totalAddDmgVal =
        (nextStats.addDmg + nextStats.counterAddDmg) / 100 +
        finalHighestEleAdd +
        fireAdd +
        waterAdd +
        lightAdd +
        darkAdd;
      const addDmgFactor = 1 + totalAddDmgVal;

      const skillAtkFactor = totalSkillAtkRatio;
      const allTypeFactor = totalAllTypeDmgRatio;
      const finalDmgIncFactor = totalFinalDmgRatio;

      // 상태이상
      const {
        poisonDmg,
        bleedDmg,
        burnDmg,
        shockDmg,
        poisonInc,
        bleedInc,
        burnInc,
        shockInc,
      } = nextStats.status;
      const poisonFactor = (poisonDmg / 100) * (1 + poisonInc / 100);
      const bleedFactor = (bleedDmg / 100) * (1 + bleedInc / 100);
      const burnFactor = (burnDmg / 100) * (1 + burnInc / 100);
      const shockFactor = (shockDmg / 100) * (1 + shockInc / 100);
      const totalStatusFactor =
        poisonFactor + bleedFactor + burnFactor + shockFactor;

      // 최종 계산
      const SKILL_PERCENT = 100;
      const hitDmg =
        mainAtkVal *
        statFactor *
        eleFactor *
        critFactor *
        dmgIncFactor *
        addDmgFactor *
        skillAtkFactor *
        allTypeFactor *
        finalDmgIncFactor *
        SKILL_PERCENT;

      const statusTotalDmg = hitDmg * totalStatusFactor;
      const grandTotalDmg = hitDmg + statusTotalDmg;

      // --- UI 업데이트 ---
      const uiStats = {
        ...nextStats,
        ...nextStats.status, // status 객체 펼치기
        str: Math.floor(finalStr),
        int: Math.floor(finalInt),
        physAtk: Math.floor(finalPhysAtk),
        magAtk: Math.floor(finalMagAtk),
        skillAtkInc: ((totalSkillAtkRatio - 1) * 100).toFixed(1),
        allTypeDmg: ((totalAllTypeDmgRatio - 1) * 100).toFixed(1),
        finalDmg: ((totalFinalDmgRatio - 1) * 100).toFixed(1),
      };

      setFinalStats(uiStats);
      setFinalDamageInfo({
        normal: Math.floor(hitDmg),
        status: Math.floor(statusTotalDmg),
        total: Math.floor(grandTotalDmg),
      });
      setTotalGearPoint(nextStats.gearPoint || 0);
    }, 16); // 16ms 딜레이
    return () => clearTimeout(timer); // 클린업
  }, [userStats]);

  // -------------------------------------------------------
  // [렌더링 헬퍼 1] 장비 슬롯 카드
  // ------------------------------------------------------=

  // 모달 열 때 버퍼 초기화 헬퍼
  const openSubModal = (subType, slot) => {
    // 현재 해당 슬롯의 전체 스탯을 복사해서 버퍼에 넣음
    setEditBuffer({ ...userStats });
    setActiveModal({ type: subType, slot });
  };

  // 버퍼 내용 업데이트
  const updateBuffer = (category, key, value) => {
    setEditBuffer((prev) => ({
      ...prev,
      [category]: { ...prev[category], [slot]: value }, // slot은 activeModal.slot 사용 불가하므로 아래에서 처리
    }));
  };
  // -------------------------------------------------------
  // [렌더링 헬퍼] 장비 슬롯 카드 (칭호 예외 처리 적용)
  // -------------------------------------------------------
  const renderGearSlotCard = (slot) => {
    const eq = userStats.equipment[slot];
    const isEquipped = eq.itemId !== 0;
    const isCash = SPECIAL_SLOTS.includes(slot);
    const isTitle = slot === "칭호";

    // 1. 기본 정보 설정
    let iconUrl = null,
      gradeClass = "",
      displayName = "",
      nameColor = "#888";
    if (isEquipped) {
      const db = slot === "무기" ? WEAPON_DB : GEAR_DB;
      const item = db.find((i) => i.id === eq.itemId);
      if (item) {
        iconUrl = GET_ITEM_ICON(item.name, slot);
        if (item.grade.includes("익시드")) gradeClass = "grade-exceed";
        else if (item.grade.includes("에픽")) gradeClass = "grade-epic";
        else if (item.grade.includes("유니크")) gradeClass = "grade-unique";
        else if (item.grade.includes("레어")) gradeClass = "grade-rare";
        displayName = item.name;
        nameColor = getGradeColor(item.grade);
      }
    }
    const emptyIconUrl = `${IMAGE_BASE_URL}/empty/${
      SLOT_ENG_NAMES[slot] || "default"
    }.png`;

    // 2. 인디케이터 데이터
    const reinforceVal = userStats.reinforce[slot] || 0;
    let reinforceClass = "rf-white";
    if (reinforceVal >= 20) reinforceClass = "rf-red";
    else if (reinforceVal >= 15) reinforceClass = "rf-epic";

    // 마법봉인
    let mGroup = null;
    if (slot === "무기") mGroup = "무기";
    else if (["머리어깨", "상의", "하의", "벨트", "신발"].includes(slot))
      mGroup = "방어구";
    else if (["팔찌", "목걸이", "반지"].includes(slot)) mGroup = "악세서리";
    else mGroup = "특수장비";
    const magicData = MAGIC_OPTS_BY_GROUP[mGroup];
    const getSealColorClass = (label, type) => {
      if (!label || label === "선택 안함" || !magicData) return "seal-none";
      const list = magicData[type] || [];
      const found = list.find((opt) => opt.label === label);
      if (!found) return "seal-mid";
      if (found.tier === "bis") return "seal-bis";
      if (found.tier === "high") return "seal-high";
      return "seal-mid";
    };
    const sealUniqueClass = getSealColorClass(
      userStats.magic_unique[slot],
      "unique"
    );
    const sealCommonClass = getSealColorClass(
      userStats.magic_common[slot],
      "common"
    );
    const showSeal =
      (sealUniqueClass !== "seal-none" || sealCommonClass !== "seal-none") &&
      !isCash;

    // 마법부여
    const enchantName = userStats.enchant[slot];
    let enchantClass = "color-none";
    if (enchantName && enchantName !== "선택 안함") {
      if (enchantName.includes("[종결]")) enchantClass = "color-bis";
      else if (enchantName.includes("[준종결]")) enchantClass = "color-high";
      else enchantClass = "color-mid";
    }
    const showEnchant = enchantClass !== "color-none" && (!isCash || isTitle);

    // 연마
    const pVal = userStats.polish[slot] || 0;
    let pClass = "refine-low";
    if (pVal === 10) pClass = "refine-max";
    else if (pVal >= 7) pClass = "refine-super";
    else if (pVal >= 5) pClass = "refine-high";
    else if (pVal >= 4) pClass = "refine-mid";

    // ★ [New] 엠블렘 (양갈래 머리) 설정
    // 1) 위치 결정 (Left Column vs Right Column)
    const leftSlots = [
      "머리어깨",
      "상의",
      "하의",
      "벨트",
      "신발",
      "오라",
      "크리쳐",
    ];
    // 나머지는 오른쪽 (무기, 악세, 특장, 칭호, 아티팩트)
    const pigtailSide = leftSlots.includes(slot)
      ? "pigtail-left"
      : "pigtail-right";

    // 2) 데이터 가져오기
    const emblemRule = EMBLEM_RULES[slot] || { slots: 0 };
    const currentEmblems = Array.isArray(userStats.emblem[slot])
      ? userStats.emblem[slot]
      : Array(emblemRule.slots).fill(null);

    // 3) 표시 여부: 칭호이거나 캐시가 아닌 경우에만 엠블렘 슬롯 표시
    const showEmblemPigtails = (!isCash || isTitle) && emblemRule.slots > 0;

    // 4) 클릭 핸들러 (바로 엠블렘 모달로, fromBlacksmith: false)
    const openEmblemModal = (e) => {
      e.stopPropagation();
      setEditBuffer(JSON.parse(JSON.stringify(userStats))); // 버퍼 초기화 필수
      setActiveModal({ type: "EMBLEM", slot, fromBlacksmith: false });
    };

    const handleClick = () => {
      // 1. 무기 슬롯 클릭 시 로직 변경
      if (slot === "무기") {
        // 직업군 선택 여부 확인
        if (!userStats.character.baseJob)
          return alert("직업군을 먼저 선택해주세요.");

        // 해당 직업군의 무기 목록 가져오기
        const types = WEAPON_TYPES[userStats.character.baseJob] || [];

        // 첫 번째 무기 타입을 기본 탭으로 설정 (이미 설정된 게 있으면 유지해도 됨)
        // 여기서는 모달 열 때마다 첫 번째로 초기화하거나, 기존 값을 유지할 수 있음.
        // 편의상 기존에 선택한 타입이 없으면 첫 번째 것으로 설정
        if (!weaponFilter || !types.includes(weaponFilter)) {
          setWeaponFilter(types[0] || "");
        }

        setActiveModal({ type: "GEAR_PICKER", slot });
      }
      // 2. 스페셜 장비
      else if (isCash) {
        setActiveModal({ type: "SPECIAL_PICKER", slot });
      }
      // 3. 일반 장비
      else {
        setActiveModal({ type: "GEAR_PICKER", slot });
      }
    };

    return (
      <div className="slot-wrapper" key={slot}>
        <div className="slot-icon-box">
          {/* ★ 엠블렘 양갈래 UI */}
          {showEmblemPigtails && (
            <div className={`pigtail-container ${pigtailSide}`}>
              {[...Array(emblemRule.slots)].map((_, i) => {
                const emb = currentEmblems[i];
                return (
                  <div
                    key={i}
                    className={`pigtail-emblem ${emb ? "" : "pigtail-empty"}`}
                    onClick={openEmblemModal}
                  >
                    {emb && (
                      <>
                        <img
                          src={`${IMAGE_BASE_URL}/emblems/${emb.img}.png`}
                          className="pigtail-img"
                          alt=""
                          onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                        />
                        {/* ★ 레벨 숫자 오버레이 추가 */}
                        <div className="pigtail-lv-overlay">{emb.level}</div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          <div
            className={`game-slot ${gradeClass} ${
              isEquipped ? "equipped" : ""
            }`}
            onClick={handleClick}
          >
            {iconUrl ? (
              <img
                src={iconUrl}
                alt={slot}
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = PLACEHOLDER_IMG;
                }}
              />
            ) : (
              <img src={emptyIconUrl} alt={slot} className="empty-slot-img" />
            )}
            {reinforceVal > 0 && !isCash && (
              <div className={`indicator-reinforce ${reinforceClass}`}>
                +{reinforceVal}
              </div>
            )}
            {pVal > 0 && !isCash && (
              <div className={`indicator-refine ${pClass}`}>{pVal}연마</div>
            )}
            {showSeal && (
              <div className="indicator-seal">
                <span className={`seal-gem ${sealUniqueClass}`}>♦</span>
                <span className={`seal-gem ${sealCommonClass}`}>♦</span>
              </div>
            )}
            {showEnchant && (
              <div className={`indicator-enchant ${enchantClass}`}>🂠</div>
            )}
          </div>

          {(!isCash || isTitle) && isEquipped && (
            <div
              className="blacksmith-btn"
              onClick={(e) => {
                e.stopPropagation();
                setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                setActiveModal({ type: "BLACKSMITH", slot });
              }}
              title="대장간 설정"
            >
              🔨
            </div>
          )}
        </div>
        {isEquipped && (
          <div className="slot-name-tag" style={{ color: nameColor }}>
            {displayName}
          </div>
        )}
      </div>
    );
  };

  // [App.js] renderInnerModal (Fix: 중복 제거 & 스킬 레벨링 로직 강화)
  const renderInnerModal = () => {
    if (!activeModal.type) return null;
    const { type, slot } = activeModal;

    // [1] Bottom Sheet 위임
    if (["GEAR_PICKER", "SPECIAL_PICKER"].includes(type)) {
      return renderBottomSheet();
    }

    // --- 공통 핸들러 ---
    const close = () => {
      setActiveModal({ type: null, slot: null });
      setEditBuffer({});
    };

    const backToMain = () => {
      setEditBuffer({});
      // 돌아갈 상위 모달 지정
      if (
        ["MAGIC_POWER", "HOPAE", "BREAKTHROUGH", "CASTLE_SEAL"].includes(type)
      ) {
        setActiveModal({ type: "JOURNAL", slot: null });
      } else if (["AVATAR_SET", "AVATAR_WEAPON"].includes(type)) {
        setActiveModal({ type: "AVATAR_MAIN", slot: null });
      } else if (
        ["REINFORCE", "POLISH", "ENCHANT", "MAGIC", "EMBLEM"].includes(type)
      ) {
        if (activeModal.fromBlacksmith) {
          setActiveModal({ type: "BLACKSMITH", slot });
        } else {
          close();
        }
      } else {
        close();
      }
    };

    // ★ [핵심 1] 데이터 저장 로직 (Deep Merge 강화)
    const handleApply = () => {
      setUserStats((prev) => {
        const next = { ...prev };

        Object.keys(editBuffer).forEach((key) => {
          // 객체 데이터(training, avatarSettings 등)는 기존 데이터를 먼저 깔고 덮어씁니다.
          if (
            typeof editBuffer[key] === "object" &&
            !Array.isArray(editBuffer[key]) &&
            editBuffer[key] !== null
          ) {
            next[key] = {
              ...prev[key], // 1. 기존 데이터 보존
              ...editBuffer[key], // 2. 수정된 데이터 덮어쓰기
            };
          } else {
            // 배열이나 원시값은 그대로 교체
            next[key] = editBuffer[key];
          }
        });
        return next;
      });

      // 적용 후 이동 경로
      if (
        [
          "BLACKSMITH",
          "JOURNAL",
          "SKILL_RUNE",
          "AVATAR_MAIN",
          "SKILL_TREE",
        ].includes(type)
      ) {
        close();
      } else {
        backToMain();
      }
    };

    // 헬퍼: 성안의 봉인 버퍼 업데이트
    const updateSealBuffer = (key, val) => {
      setEditBuffer((prev) => ({
        ...prev,
        training: {
          ...(prev.training || userStats.training), // 현재 유저 스탯 기반으로 초기화 안 되게 방어
          ...prev.training, // 이미 수정 중인 내용이 있다면 유지
          [key]: val,
        },
      }));
    };

    // --- 내부 함수: 스킬트리 모달 (vFinal: 레벨링 로직 연결) ---
    const renderSkillTreeModal = () => {
      const { baseJob, subJob, level: charLevel } = userStats.character;
      const { masterContract } = userStats.training;

      if (!subJob) {
        return (
          <div
            className="item-picker-modal"
            style={{ zIndex: 30000 }}
            onClick={close}
          >
            <div
              className="alert-modal-content"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="alert-message">
                ⚠️
                <br />
                직업을 먼저 선택해주세요.
              </div>
              <button className="alert-btn" onClick={close}>
                확인
              </button>
            </div>
          </div>
        );
      }

      // ★ [핵심 2] 스킬 레벨링 소스 수집 (DB 매칭 & 중첩 객체 탐색)
      const levelingMap = {};

      // 1. 아바타 세트 찾기
      const currentAvatarSet = userStats.avatarSettings.set;
      const avatarItem =
        currentAvatarSet && currentAvatarSet !== "없음"
          ? AVATAR_DB[currentAvatarSet]
          : null;

      // 2. 무기 아바타 찾기
      const currentWeaponAvatar = userStats.avatarSettings.weapon;
      const weaponAvatarItem =
        currentWeaponAvatar && currentWeaponAvatar !== "없음"
          ? WEAPON_AVATAR_DB.find((it) => it.name === currentWeaponAvatar)
          : null;

      // 3. 성안의 봉인 찾기
      const { sealMain, sealSub } = userStats.training;
      const sealMainItem = sealMain
        ? TRAINING_DB.castle_seal?.main.find((it) => it.name === sealMain)
        : null;
      const sealSubItem = sealSub
        ? TRAINING_DB.castle_seal?.sub.find((it) => it.name === sealSub)
        : null;

      // 모든 소스 통합
      const allItems = [
        ...Object.values(userStats.selections || {}),
        ...Object.values(userStats.emblems || {})
          .flat()
          .filter(Boolean),
        ...Object.values(userStats.enchants || {}),
        ...Object.values(userStats.refines || {}),
        avatarItem, // 아바타 세트
        weaponAvatarItem, // 무기 아바타
        sealMainItem, // 성안 메인
        sealSubItem, // 성안 서브
      ].filter(Boolean);

      // 레벨링 파싱
      allItems.forEach((item) => {
        // stats와 _raw 모두 스캔
        const sources = [item.stats, item._raw].filter(Boolean);

        sources.forEach((src) => {
          // A. 중첩 객체 구조 확인 (stats.skill.lv) -> 하단 패널이 쓰는 구조
          if (src.skill && src.skill.lv) {
            Object.entries(src.skill.lv).forEach(([k, v]) => {
              // k: "lv15", "15" 등
              const match = String(k).match(/(\d+)/);
              if (match) {
                const levelNum = Number(match[1]);
                if (levelNum > 0) {
                  levelingMap[levelNum] =
                    (levelingMap[levelNum] || 0) + (Number(v) || 0);
                }
              }
            });
          }

          // B. 평면 키 구조 확인 (stats_skill_lv_lv15 등) -> 엑셀 원본 구조
          Object.keys(src).forEach((key) => {
            const k = String(key)
              .toLowerCase()
              .replace(/[^a-z0-9]/g, ""); // 특수문자 제거, 소문자화
            const val = Number(src[key]);
            if (!val) return;

            // "lv" 뒤에 숫자가 붙은 패턴 검색
            // 예: stats_skill_lv_lv15 -> lv15 -> 15 추출
            // 예: active_lv_30 -> lv30 -> 30 추출
            const match = k.match(/lv(\d+)/);
            if (match) {
              const levelNum = Number(match[1]);
              // skill 객체 내부가 아닌 평면 키인 경우에만 추가 (중복 방지)
              // (간단하게 그냥 더해도 됨, 어차피 소스가 다르면 키가 다르므로)
              if (levelNum > 0 && key !== "skill") {
                // skill 객체 자체는 위 A단계에서 처리했으므로 제외
                levelingMap[levelNum] = (levelingMap[levelNum] || 0) + val;
              }
            }
          });
        });
      });

      // 1. 데이터 준비
      const allMySkills = SKILL_DB.filter((s) => {
        const isJob =
          String(s.jobGroup).replace(/\s/g, "") ===
          String(baseJob).replace(/\s/g, "");
        const isSub =
          String(s.jobName).replace(/\s/g, "") ===
            String(subJob).replace(/\s/g, "") || s.jobName === "공용";
        return isJob && isSub;
      });

      // 2. 그룹 분리
      const sortSk = (a, b) => {
        if (a.rowIndex !== b.rowIndex) return a.rowIndex - b.rowIndex;
        if (a.id < b.id) return -1;
        if (a.id > b.id) return 1;
        return 0;
      };

      const commonSkills = allMySkills
        .filter((s) => s.category === "common")
        .sort(sortSk);
      const basicSkills = allMySkills
        .filter((s) => s.category === "basic")
        .sort(sortSk);
      const normalSkills = allMySkills
        .filter((s) => s.category !== "common" && s.category !== "basic")
        .sort((a, b) => a.startLv - b.startLv);

      const distinctLevels = [
        ...new Set(normalSkills.map((s) => s.startLv)),
      ].sort((a, b) => a - b);

      // 3. SP/TP 계산
      const MAX_SP = 12100;
      const MAX_TP = 45;
      let usedSP = 0;
      let usedTP = 0;

      allMySkills.forEach((s) => {
        const lv = userStats.skill.levels[s.id] || s.minLv;
        const tp = userStats.skill.tpLevels[s.id] || 0;
        const isSingle = s.minLv === 1 && s.maxLv === 1;
        if (!isSingle) usedSP += lv * s.spCost;
        usedTP += tp * s.tpCost;
      });

      const remainSP = MAX_SP - usedSP;
      const remainTP = MAX_TP - usedTP;

      const getRealStartLv = (s) =>
        Math.max(1, s.startLv - (masterContract ? 5 : 0));

      // 4. 핸들러
      const handleLevelChange = (skill, delta, isShift) => {
        if (skill.minLv === 1 && skill.maxLv === 1) return;

        const cur = userStats.skill.levels[skill.id] || skill.minLv;
        const realStartLv = getRealStartLv(skill);
        const levelLimit =
          Math.floor((charLevel - realStartLv) / skill.levelStep) + 1;
        const realMax = Math.max(0, Math.min(skill.maxLv, levelLimit));

        let next = cur;
        if (isShift) {
          if (delta > 0) {
            const maxPossibleBySP = Math.floor(remainSP / skill.spCost) + cur;
            next = Math.min(realMax, maxPossibleBySP);
          } else {
            next = skill.minLv;
          }
        } else {
          next = Math.max(skill.minLv, Math.min(realMax, cur + delta));
        }

        if (next === cur) return;
        if (next > cur && (next - cur) * skill.spCost > remainSP) return;
        updateStat("skill", "levels", {
          ...userStats.skill.levels,
          [skill.id]: next,
        });
      };

      const handleTpChange = (skill, delta, isShift) => {
        if (!skill.tpCost) return;
        const cur = userStats.skill.tpLevels[skill.id] || 0;

        let next = cur;
        if (isShift) {
          if (delta > 0) {
            const maxPossibleByTP = Math.floor(remainTP / skill.tpCost) + cur;
            next = Math.min(5, maxPossibleByTP);
          } else {
            next = 0;
          }
        } else {
          next = Math.max(0, Math.min(5, cur + delta));
        }

        if (next === cur) return;
        if (next > cur && (next - cur) * skill.tpCost > remainTP) return;
        updateStat("skill", "tpLevels", {
          ...userStats.skill.tpLevels,
          [skill.id]: next,
        });
      };

      // 타일 렌더링
      const renderSkillTile = (skill) => {
        const baseLv = userStats.skill.levels[skill.id] || skill.minLv;
        const tp = userStats.skill.tpLevels[skill.id] || 0;
        const realStartLv = getRealStartLv(skill);
        const levelLimit =
          Math.floor((charLevel - realStartLv) / skill.levelStep) + 1;

        const masterMax = Math.max(0, Math.min(skill.maxLv, levelLimit));

        // ★ [Fix] 레벨링 보너스 추출 (startLv 기준)
        const bonusLv = levelingMap[skill.startLv] || 0;

        // 최종 레벨 (한계 돌파 적용)
        const finalLv = Math.min(baseLv + bonusLv, skill.limitLv);

        const isSingleMaster = skill.minLv === 1 && skill.maxLv === 1;
        const isMasterReached = baseLv >= masterMax && masterMax > 0;
        const isLocked = charLevel < realStartLv;

        let statusClass = "inactive";
        if (isLocked) statusClass = "locked";
        else if (finalLv > 0) statusClass = "active";

        const levelTextClass =
          bonusLv > 0 && finalLv > baseLv ? "text-green" : "";

        let displayText = `${finalLv}/${masterMax}`;
        let isMasterText = false;

        if (isSingleMaster) {
          displayText = `${finalLv}/1`;
        } else {
          displayText = `${finalLv}/${masterMax}`;
          if (isMasterReached) isMasterText = true;
        }

        return (
          <div key={skill.id} className={`st-v-tile ${statusClass}`}>
            <div
              className="st-v-icon-box"
              onClick={(e) =>
                !isLocked &&
                !isSingleMaster &&
                handleLevelChange(skill, 1, e.shiftKey)
              }
            >
              <img
                src={`${IMAGE_BASE_URL}/skills/${encodeURIComponent(
                  skill.jobName
                )}/${(skill.img || "default").replace(".png", "")}.png`}
                alt=""
                onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
              />
              {tp > 0 && <div className="st-v-tp-star">★</div>}
            </div>

            {isSingleMaster ? (
              <div className="st-v-control-bar single">
                <div className="st-v-center-info">
                  <div className="st-v-skill-name">{skill.name}</div>
                  <div className="st-v-meta-row">
                    {skill.spCost > 0 && (
                      <span className="st-meta-tag sp">{skill.spCost}</span>
                    )}
                    {skill.cooltime > 0 && (
                      <span className="st-meta-tag cool">
                        {skill.cooltime}s
                      </span>
                    )}
                    {skill.tpCost > 0 && (
                      <span className="st-meta-tag tp">{skill.tpCost}</span>
                    )}
                  </div>
                  <div className={`st-v-lv-display master ${levelTextClass}`}>
                    {displayText}
                  </div>
                </div>
              </div>
            ) : (
              <div className="st-v-control-bar">
                <div className="st-v-btn-stack sp">
                  <button
                    className="st-v-tiny-btn"
                    disabled={isLocked || baseLv >= masterMax}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleLevelChange(skill, 1, e.shiftKey);
                    }}
                  >
                    ▲
                  </button>
                  <span className="st-v-stack-label sp">SP</span>
                  <button
                    className="st-v-tiny-btn"
                    disabled={isLocked || baseLv <= skill.minLv}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleLevelChange(skill, -1, e.shiftKey);
                    }}
                  >
                    ▼
                  </button>
                </div>

                <div className="st-v-center-info">
                  <div className="st-v-skill-name">{skill.name}</div>
                  <div className="st-v-meta-row">
                    {skill.spCost > 0 && (
                      <span className="st-meta-tag sp">{skill.spCost}</span>
                    )}
                    {skill.cooltime > 0 && (
                      <span className="st-meta-tag cool">
                        {skill.cooltime}s
                      </span>
                    )}
                    {skill.tpCost > 0 && (
                      <span className="st-meta-tag tp">{skill.tpCost}</span>
                    )}
                  </div>
                  <div
                    className={`st-v-lv-display ${levelTextClass} ${
                      isMasterText ? "master" : ""
                    }`}
                  >
                    {displayText}
                  </div>
                  {skill.tpCost > 0 && (
                    <div className="st-v-tp-val">TP {tp}</div>
                  )}
                </div>

                <div
                  className="st-v-btn-stack tp"
                  style={{
                    visibility: skill.tpCost > 0 ? "visible" : "hidden",
                  }}
                >
                  <button
                    className="st-v-tiny-btn"
                    disabled={isLocked || tp >= 5}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTpChange(skill, 1, e.shiftKey);
                    }}
                  >
                    ▲
                  </button>
                  <span className="st-v-stack-label tp">TP</span>
                  <button
                    className="st-v-tiny-btn"
                    disabled={isLocked || tp <= 0}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTpChange(skill, -1, e.shiftKey);
                    }}
                  >
                    ▼
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      };

      return (
        <div className="item-picker-modal" onClick={close}>
          <div
            className="picker-content skill-modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="st3-header">
              <div className="st3-resource-bar">
                <div className="st-counter">
                  <span className="st-label sp">SP</span>
                  <span className="st-val">{remainSP.toLocaleString()}</span>
                </div>
                <div className="st-counter">
                  <span className="st-label tp">TP</span>
                  <span className="st-val">{remainTP.toLocaleString()}</span>
                </div>
              </div>
              <div className="st3-title-area">
                <h3>
                  스킬트리{" "}
                  <span
                    style={{
                      fontSize: "0.6em",
                      color: "#666",
                      fontWeight: "normal",
                      marginLeft: "8px",
                    }}
                  >
                    (Lv.{charLevel})
                  </span>
                </h3>
                <div className="st-guide-text">
                  <span className="st-key-badge">Shift</span>+ 클릭 : 최대/최소
                  설정
                </div>
              </div>
              <button className="picker-close-btn" onClick={close}>
                ✕
              </button>
            </div>

            <div className="st-vertical-body">
              {commonSkills.length > 0 && (
                <div className="st-v-band">
                  <div
                    className="st-v-level-label"
                    style={{ fontSize: "12px", color: "#aaa" }}
                  >
                    공통
                  </div>
                  <div className="st-v-grid">
                    {[1, 2, 3, 4, 5, 6].map((idx) => (
                      <div key={idx} className="st-v-col-stack">
                        {commonSkills
                          .filter((s) => s.rowIndex === idx)
                          .map((s) => renderSkillTile(s))}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {basicSkills.length > 0 && (
                <div className="st-v-band">
                  <div
                    className="st-v-level-label"
                    style={{ fontSize: "12px", color: "#aaa" }}
                  >
                    기본
                  </div>
                  <div className="st-v-grid">
                    {[1, 2, 3, 4, 5, 6].map((idx) => (
                      <div key={idx} className="st-v-col-stack">
                        {basicSkills
                          .filter((s) => s.rowIndex === idx)
                          .map((s) => renderSkillTile(s))}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {distinctLevels.map((lvKey) => (
                <div key={lvKey} className="st-v-band">
                  <div className="st-v-level-label">{lvKey}</div>
                  <div className="st-v-grid">
                    {normalSkills
                      .filter((s) => s.startLv === lvKey)
                      .map((skill) => renderSkillTile(skill))}
                  </div>
                </div>
              ))}
              <div style={{ height: "100px" }}></div>
            </div>
          </div>
        </div>
      );
    };

    // ★ 1. 스킬트리 호출
    if (type === "SKILL_TREE") {
      return renderSkillTreeModal();
    }

    // 2. 캐릭터 레벨 슬라이더
    if (type === "CHAR_LEVEL") {
      return (
        <StatSlider
          value={editBuffer.training?.charLevel || 85}
          max={85}
          onChange={(val) =>
            setEditBuffer((prev) => ({
              ...prev,
              training: { ...prev.training, charLevel: val },
            }))
          }
          onCancel={close}
          onApply={() => {
            updateStat("character", "level", editBuffer.training.charLevel);
            close();
          }}
        />
      );
    }

    // 초기화 버튼 로직
    const handleResetBuffer = () => {
      const resetKeyMap = {
        REINFORCE: () => updateBuffer("reinforce", slot, 0),
        POLISH: () => updateBuffer("polish", slot, 0),
        ENCHANT: () => updateBuffer("enchant", slot, "선택 안함"),
        MAGIC: () =>
          setEditBuffer((prev) => ({
            ...prev,
            magic_unique: { ...prev.magic_unique, [slot]: "선택 안함" },
            magic_common: { ...prev.magic_common, [slot]: "선택 안함" },
          })),
        EMBLEM: () => {
          const arr = editBuffer.emblem?.[slot] || [];
          const newArr = arr.length > 0 ? arr.map(() => null) : [null, null];
          updateBufferDeep("emblem", -1, newArr);
        },
        CASTLE_SEAL: () => {
          updateSealBuffer("sealMain", "");
          updateSealBuffer("sealSub", "");
        },
      };
      if (resetKeyMap[type]) resetKeyMap[type]();
    };

    // 헬퍼 함수들
    const updateBuffer = (category, key, value) => {
      setEditBuffer((prev) => ({
        ...prev,
        [category]: { ...prev[category], [slot]: value },
      }));
    };
    const updateBufferDeep = (category, idx, value) => {
      if (idx === -1) {
        setEditBuffer((prev) => ({
          ...prev,
          [category]: { ...prev[category], [slot]: value },
        }));
        return;
      }
      const arr = [...(editBuffer[category]?.[slot] || [])];
      arr[idx] = value;
      setEditBuffer((prev) => ({
        ...prev,
        [category]: { ...prev[category], [slot]: arr },
      }));
    };
    const handleSliderChange = (key, val, max) => {
      let safeVal = Math.max(0, Math.min(val, max));
      setEditBuffer((prev) => ({
        ...prev,
        training: { ...prev.training, [key]: safeVal },
      }));
    };

    // 키보드 핸들러
    const handleKeyDown = (e) => {
      e.stopPropagation();
      if (type === "JOB_SELECTOR" || type === "CLASS_SELECTOR") return;
      if (e.key === "Enter") handleApply();
      else if (e.key === "Escape") {
        if (
          ["BLACKSMITH", "JOURNAL", "SKILL_RUNE", "AVATAR_MAIN"].includes(type)
        )
          close();
        else backToMain();
      }
    };

    const MODAL_TITLE_MAP = {
      JOURNAL: "수련 일지",
      MAGIC_POWER: "마력 응축기",
      HOPAE: "호패 강화",
      BREAKTHROUGH: "장비 돌파",
      CASTLE_SEAL: "성안의 봉인",
      SKILL_RUNE: "스킬룬 설정",
      AVATAR_MAIN: "아바타 설정",
      AVATAR_SET: "아바타 세트",
      AVATAR_WEAPON: "무기 아바타",
      BLACKSMITH: "대장간",
      REINFORCE: "장비 강화",
      POLISH: "장비 연마",
      ENCHANT: "마법부여",
      MAGIC: "마법봉인",
      EMBLEM: "엠블렘",
    };

    // [2] 직업/전직 선택
    if (type === "JOB_SELECTOR" || type === "CLASS_SELECTOR") {
      // ... (기존 직업/전직 선택 로직 유지) ...
      // (길어서 생략했지만 기존 코드 그대로 두시면 됩니다)
      const isJob = type === "JOB_SELECTOR";
      const title = isJob ? "직업군 선택" : "전직 선택";
      const list = isJob
        ? Object.keys(JOB_STRUCTURE)
        : userStats.character.baseJob
        ? JOB_STRUCTURE[userStats.character.baseJob]
        : [];
      return (
        <div className="job-picker-modal" onClick={close}>
          <div
            className="job-picker-content"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="picker-header">
              <h3>{title}</h3>
              <button className="picker-close-btn" onClick={close}>
                ✕
              </button>
            </div>
            <div
              className={isJob ? "job-grid-container" : "class-row-container"}
            >
              {list.map((name) => (
                <div
                  key={name}
                  className={isJob ? "job-card" : "class-card-small"}
                  onClick={() => {
                    if (isJob) {
                      updateStat("character", "baseJob", name);
                      updateStat("character", "subJob", "");
                      updateStat("character", "weaponType", "");
                      handleGearUpdate("무기", 0);
                    } else {
                      updateStat("character", "subJob", name);
                    }
                    close();
                  }}
                >
                  {isJob ? (
                    <>
                      <div className="job-icon-box">
                        <img
                          src={GET_JOB_ICON("job", name)}
                          alt={name}
                          onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                        />
                      </div>
                      <div className="job-name-tag">{name}</div>
                    </>
                  ) : (
                    <>
                      <div className="class-thumb">
                        <img
                          src={GET_JOB_ICON("class", name)}
                          alt={name}
                          onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                        />
                      </div>
                      <div className="class-name-overlay">{name}</div>
                    </>
                  )}
                </div>
              ))}
              {list.length === 0 && !isJob && (
                <div
                  style={{ padding: 30, color: "#888", textAlign: "center" }}
                >
                  직업군을 먼저 선택해주세요.
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    // [3] 통합 렌더링
    const renderContent = () => {
      // --- [A] 수련일지 ---
      if (type === "JOURNAL") {
        const { concentrator, hopae, breakthrough, sealMain, sealSub } =
          userStats.training;
        let sealText =
          sealMain || sealSub
            ? sealMain && sealSub
              ? `${sealMain} / ${sealSub}`
              : sealMain || sealSub
            : "미설정";
        const openJournalSub = (subType) => {
          setEditBuffer(JSON.parse(JSON.stringify(userStats)));
          setActiveModal({ type: subType, slot: null });
        };
        return (
          <div className="bs-grid">
            <div
              className="bs-box"
              onClick={() => openJournalSub("MAGIC_POWER")}
            >
              <img
                src={`${IMAGE_BASE_URL}/journal/magic.png`}
                className="bs-icon-img"
                alt="마력"
                onError={(e) => {
                  e.target.src = PLACEHOLDER_IMG;
                }}
              />
              <div className="bs-title">마력 응축기</div>
              <div
                className={`bs-value-text ${
                  concentrator > 0 ? "highlight" : ""
                }`}
              >
                {concentrator}단계
              </div>
            </div>
            <div className="bs-box" onClick={() => openJournalSub("HOPAE")}>
              <img
                src={`${IMAGE_BASE_URL}/journal/hopae.png`}
                className="bs-icon-img"
                alt="호패"
                onError={(e) => {
                  e.target.src = PLACEHOLDER_IMG;
                }}
              />
              <div className="bs-title">호패</div>
              <div className={`bs-value-text ${hopae > 0 ? "highlight" : ""}`}>
                {hopae}단계
              </div>
            </div>
            <div
              className="bs-box"
              onClick={() => openJournalSub("BREAKTHROUGH")}
            >
              <img
                src={`${IMAGE_BASE_URL}/journal/breakthrough.png`}
                className="bs-icon-img"
                alt="돌파"
                onError={(e) => {
                  e.target.src = PLACEHOLDER_IMG;
                }}
              />
              <div className="bs-title">돌파</div>
              <div
                className={`bs-value-text ${
                  breakthrough > 0 ? "highlight" : ""
                }`}
              >
                {breakthrough}단계
              </div>
            </div>
            <div
              className="bs-box"
              onClick={() => openJournalSub("CASTLE_SEAL")}
            >
              <img
                src={`${IMAGE_BASE_URL}/journal/seal.png`}
                className="bs-icon-img"
                alt="성안"
                onError={(e) => {
                  e.target.src = PLACEHOLDER_IMG;
                }}
              />
              <div className="bs-title">성안의 봉인</div>
              <div
                className={`bs-value-text ${
                  sealText !== "미설정" ? "highlight" : ""
                }`}
                style={{
                  fontSize: "0.75rem",
                  lineHeight: "1.2",
                  padding: "0 5px",
                }}
              >
                {sealText}
              </div>
            </div>
          </div>
        );
      }
      if (["MAGIC_POWER", "HOPAE", "BREAKTHROUGH"].includes(type)) {
        let key = "";
        let max = 0;
        if (type === "MAGIC_POWER") {
          key = "concentrator";
          max = 4;
        } else if (type === "HOPAE") {
          key = "hopae";
          max = 3;
        } else if (type === "BREAKTHROUGH") {
          key = "breakthrough";
          max = 10;
        }
        const val = editBuffer.training?.[key] || 0;
        return (
          <StatSlider
            value={val}
            max={max}
            onChange={(newVal) => handleSliderChange(key, newVal, max)}
            onCancel={backToMain}
            onApply={handleApply}
          />
        );
      }
      if (type === "CASTLE_SEAL") {
        const mainVal = editBuffer.training?.sealMain || "";
        const subVal = editBuffer.training?.sealSub || "";
        const sealOptionsMain = TRAINING_DB.castle_seal?.main || [
          { name: "힘 +100" },
          { name: "지능 +100" },
        ];
        const sealOptionsSub = TRAINING_DB.castle_seal?.sub || [
          { name: "물크 +50" },
          { name: "마크 +50" },
        ];
        return (
          <div>
            <div className="magic-split-wrapper">
              <div className="magic-col-scroll">
                <div
                  className="magic-section-title"
                  style={{
                    position: "sticky",
                    top: 0,
                    background: "#111",
                    zIndex: 5,
                    paddingBottom: 5,
                  }}
                >
                  주요 옵션
                </div>
                {sealOptionsMain.map((opt) => (
                  <button
                    key={opt.name}
                    className={`bs-option-btn ${
                      mainVal === opt.name ? "active" : ""
                    }`}
                    onClick={() => updateSealBuffer("sealMain", opt.name)}
                  >
                    {opt.name}
                  </button>
                ))}
              </div>
              <div className="magic-col-scroll">
                <div
                  className="magic-section-title common"
                  style={{
                    position: "sticky",
                    top: 0,
                    background: "#111",
                    zIndex: 5,
                    paddingBottom: 5,
                  }}
                >
                  보조 옵션
                </div>
                {sealOptionsSub.map((opt) => (
                  <button
                    key={opt.name}
                    className={`bs-option-btn ${
                      subVal === opt.name ? "active" : ""
                    }`}
                    onClick={() => updateSealBuffer("sealSub", opt.name)}
                  >
                    {opt.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={() => {
                  updateSealBuffer("sealMain", "");
                  updateSealBuffer("sealSub", "");
                }}
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }

      // --- [B] 아바타 (메인/세트/무기) ---
      if (type === "AVATAR_MAIN") {
        const currentSet = userStats.avatarSettings.set;
        const currentWpn = userStats.avatarSettings.weapon;
        const openAvatarSub = (subType) =>
          setActiveModal({ type: subType, slot: null });
        return (
          <div className="bs-grid" style={{ padding: "40px 20px" }}>
            <div className="bs-box" onClick={() => openAvatarSub("AVATAR_SET")}>
              <img
                src={`${IMAGE_BASE_URL}/icons/아바타세트.png`}
                className="bs-icon-img"
                alt="세트"
                onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
              />
              <div className="bs-title">아바타 세트</div>
              <div
                className={`bs-value-text ${
                  currentSet !== "없음" ? "highlight" : ""
                }`}
              >
                {formatTextWithLineBreak(currentSet)}
              </div>
            </div>
            <div
              className="bs-box"
              onClick={() => openAvatarSub("AVATAR_WEAPON")}
            >
              <img
                src={`${IMAGE_BASE_URL}/icons/무기아바타.png`}
                className="bs-icon-img"
                alt="무기"
                onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
              />
              <div className="bs-title">무기 아바타</div>
              <div
                className={`bs-value-text ${
                  currentWpn !== "없음" ? "highlight" : ""
                }`}
              >
                {formatTextWithLineBreak(currentWpn)}
              </div>
            </div>
          </div>
        );
      }
      if (type === "AVATAR_SET") {
        const { set } = userStats.avatarSettings;
        const options = [
          "없음",
          "레어",
          "상급",
          "3레어/5상급 [공속]",
          "3레어/5상급 [캐속]",
        ];
        return (
          <div>
            <div
              className="card-grid"
              style={{ padding: "20px", maxHeight: "400px", overflowY: "auto" }}
            >
              {options.map((opt) => (
                <div
                  key={opt}
                  className={`item-card ${set === opt ? "active" : ""}`}
                  onClick={() => {
                    updateStat("avatarSettings", "set", opt);
                    backToMain();
                  }}
                >
                  <div className="card-info">
                    <div
                      className="card-name"
                      style={{ textAlign: "center", lineHeight: "1.4" }}
                    >
                      {formatTextWithLineBreak(opt)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
            </div>
          </div>
        );
      }
      if (type === "AVATAR_WEAPON") {
        const { weapon } = userStats.avatarSettings;
        const options = WEAPON_AVATAR_DB || [{ name: "없음" }];
        return (
          <div>
            <div
              className="card-grid"
              style={{ padding: "20px", maxHeight: "400px", overflowY: "auto" }}
            >
              {options.map((opt) => (
                <div
                  key={opt.name}
                  className={`item-card ${weapon === opt.name ? "active" : ""}`}
                  onClick={() => {
                    updateStat("avatarSettings", "weapon", opt.name);
                    backToMain();
                  }}
                >
                  <div className="card-info">
                    <div
                      className="card-name"
                      style={{ textAlign: "center", lineHeight: "1.4" }}
                    >
                      {formatTextWithLineBreak(opt.name)}
                    </div>
                    <div
                      className="card-set"
                      style={{
                        textAlign: "center",
                        marginTop: 6,
                        color: "#aaa",
                        fontSize: "0.8rem",
                      }}
                    >
                      {formatStatsToKor(opt.stats)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
            </div>
          </div>
        );
      }

      // --- [C] 스킬룬 (20칸 육각형 + 선택리스트) ---
      if (type === "SKILL_RUNE") {
        const currentSlots =
          editBuffer.skillRunes?.slots || Array(20).fill(null);
        const getRuneCount = (id, slots = currentSlots) =>
          slots.filter((r) => r && r.id === id).length;

        const equipRune = (runeData, isBatch = false) => {
          let nextSlots = [...currentSlots];
          const maxSpecial =
            runeData.type === "special"
              ? RUNE_CONSTANTS.special.max[runeData.id]
              : 99;
          if (isBatch) {
            let currentCount = getRuneCount(runeData.id, nextSlots);
            for (let i = 0; i < nextSlots.length; i++) {
              if (currentCount >= maxSpecial) break;
              if (nextSlots[i] === null) {
                nextSlots[i] = { ...runeData };
                currentCount++;
              }
            }
          } else {
            const currentCount = getRuneCount(runeData.id, nextSlots);
            if (currentCount >= maxSpecial) {
              alert(
                `${runeData.name}은(는) 최대 ${maxSpecial}개까지만 장착 가능합니다.`
              );
              return;
            }
            const emptyIdx = nextSlots.findIndex((s) => s === null);
            if (emptyIdx === -1) {
              alert("룬 슬롯이 가득 찼습니다. (최대 20개)");
              return;
            }
            nextSlots[emptyIdx] = { ...runeData };
          }
          setEditBuffer((prev) => ({
            ...prev,
            skillRunes: { ...prev.skillRunes, slots: nextSlots },
          }));
        };

        const unequipRune = (idx) => {
          const nextSlots = [...currentSlots];
          nextSlots[idx] = null;
          setEditBuffer((prev) => ({
            ...prev,
            skillRunes: { ...prev.skillRunes, slots: nextSlots },
          }));
        };

        return (
          <div
            style={{ display: "flex", flexDirection: "column", height: "100%" }}
          >
            <div
              style={{
                textAlign: "center",
                fontSize: "0.75rem",
                color: "#888",
                marginBottom: "10px",
              }}
            >
              <span style={{ marginRight: "15px" }}>
                🖱️ 좌클릭: 장착 / 해제
              </span>
              <span style={{ color: "var(--text-gold)" }}>
                ⇧ Shift + 좌클릭: 빈 칸 모두 채우기
              </span>
            </div>
            <div className="rune-slot-container">
              {currentSlots.map((rune, idx) => {
                let imgFileName = "empty";
                let label = "";
                if (rune) {
                  const coreName = rune.name.replace("의 룬", "");
                  imgFileName = coreName;
                  label =
                    rune.type === "special"
                      ? `${coreName}IV`
                      : `${coreName}${rune.grade === 3 ? "III" : "IV"}[${
                          rune.level
                        }]`;
                }
                return (
                  <div
                    key={idx}
                    className="rune-hex-wrapper"
                    onClick={() => rune && unequipRune(idx)}
                  >
                    <div
                      className={`rune-hex ${rune ? "equipped" : ""} ${
                        rune ? "grade-" + rune.grade : ""
                      }`}
                    >
                      {rune && (
                        <img
                          src={`${IMAGE_BASE_URL}/runes/${imgFileName}.png`}
                          alt=""
                          onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                        />
                      )}
                    </div>
                    {rune && <div className="rune-label-mini">{label}</div>}
                  </div>
                );
              })}
            </div>
            <div className="rune-selection-area">
              <div>
                <div className="rune-group-title">특수 스킬룬 (4레벨)</div>
                <div className="rune-select-row">
                  {RUNE_CONSTANTS.special.list.map((sRune) => {
                    const coreName = sRune.name.replace("의 룬", "");
                    return (
                      <div
                        key={sRune.id}
                        className="rune-option-card"
                        onClick={(e) => equipRune({ ...sRune }, e.shiftKey)}
                      >
                        <img
                          src={`${IMAGE_BASE_URL}/runes/${coreName}.png`}
                          className="rune-opt-img"
                          alt=""
                          onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                        />
                        <span style={{ fontSize: "0.8rem", color: "#00ffff" }}>
                          {sRune.name}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div style={{ marginTop: "20px" }}>
                <div className="rune-group-title">
                  일반 스킬룬 (3레벨 / 4레벨)
                </div>
                {RUNE_CONSTANTS.general.types.map((type) => (
                  <div
                    key={type}
                    style={{
                      marginBottom: "15px",
                      borderBottom: "1px solid #222",
                      paddingBottom: "10px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "10px",
                        marginBottom: "5px",
                      }}
                    >
                      <img
                        src={`${IMAGE_BASE_URL}/runes/${type}.png`}
                        style={{ width: 30, height: 30 }}
                        alt=""
                        onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                      />
                      <span style={{ fontWeight: "bold", color: "#ddd" }}>
                        {type}의 룬
                      </span>
                    </div>
                    <div
                      style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}
                    >
                      {RUNE_CONSTANTS.general.grades.map((grade) => (
                        <div
                          key={grade}
                          style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: "5px",
                            background: "#222",
                            padding: "5px",
                            borderRadius: "4px",
                          }}
                        >
                          <div
                            style={{
                              fontSize: "0.75rem",
                              color: grade === 3 ? "#b36bff" : "#ff77ff",
                              textAlign: "center",
                            }}
                          >
                            {grade === 3 ? "3레벨" : "4레벨"}
                          </div>
                          <div
                            style={{
                              display: "flex",
                              gap: "5px",
                              flexWrap: "wrap",
                              maxWidth: "300px",
                            }}
                          >
                            {RUNE_CONSTANTS.general.levels[type].map((lv) => (
                              <button
                                key={lv}
                                className="bs-option-btn"
                                style={{
                                  padding: "4px 8px",
                                  fontSize: "0.75rem",
                                  minWidth: "40px",
                                }}
                                onClick={(e) =>
                                  equipRune(
                                    {
                                      id: type,
                                      name: `${type}의 룬`,
                                      grade: grade,
                                      level: lv,
                                      type: "general",
                                    },
                                    e.shiftKey
                                  )
                                }
                              >
                                {lv}Lv
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={() =>
                  setEditBuffer((prev) => ({
                    ...prev,
                    skillRunes: { slots: Array(20).fill(null) },
                  }))
                }
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }

      // --- [D] 대장간 ---
      if (type === "BLACKSMITH") {
        const rVal = userStats.reinforce[slot] || 0;
        const pVal = userStats.polish[slot] || 0;
        const eVal = userStats.enchant[slot];
        const mUni = userStats.magic_unique[slot];
        const mCom = userStats.magic_common[slot];
        const isEnch = eVal && eVal !== "선택 안함";
        const isMagic =
          (mUni && mUni !== "선택 안함") || (mCom && mCom !== "선택 안함");
        let magicText = "미설정";
        if (isMagic)
          magicText =
            mUni !== "선택 안함" && mCom !== "선택 안함"
              ? `${mUni} / ${mCom}`
              : mUni !== "선택 안함"
              ? mUni
              : mCom;

        const isTitle = slot === "칭호";
        const isWeapon = slot === "무기";
        const isSub = slot === "보조장비";
        const showReinforce = !isTitle;
        const showPolish = !isTitle && (isWeapon || isSub);
        const showMagic = !isTitle;
        const showEnchant = true;
        const showEmblem = true;

        // ★ 모든 onClick에 { ... , fromBlacksmith: true } 추가됨
        return (
          <div className="bs-grid">
            {showReinforce && (
              <div
                className="bs-box"
                onClick={() => {
                  setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                  setActiveModal({
                    type: "REINFORCE",
                    slot,
                    fromBlacksmith: true,
                  });
                }}
              >
                <div className="bs-icon">🔨</div>
                <div className="bs-title">강화</div>
                <div className={`bs-value-text ${rVal > 0 ? "highlight" : ""}`}>
                  {rVal > 0 ? `+${rVal}강` : "0강"}
                </div>
              </div>
            )}
            {showPolish && (
              <div
                className="bs-box"
                onClick={() => {
                  setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                  setActiveModal({
                    type: "POLISH",
                    slot,
                    fromBlacksmith: true,
                  });
                }}
              >
                <div className="bs-icon">🔥</div>
                <div className="bs-title">연마</div>
                <div className={`bs-value-text ${pVal > 0 ? "highlight" : ""}`}>
                  {pVal > 0 ? `${pVal}연마` : "0연마"}
                </div>
              </div>
            )}
            <div
              className="bs-box"
              onClick={() => {
                setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                setActiveModal({ type: "ENCHANT", slot, fromBlacksmith: true });
              }}
            >
              <div className="bs-icon">🂠</div>
              <div className="bs-title">마법부여</div>
              <div className={`bs-value-text ${isEnch ? "highlight" : ""}`}>
                {isEnch ? eVal : "미설정"}
              </div>
            </div>
            {showMagic && (
              <div
                className="bs-box"
                onClick={() => {
                  setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                  setActiveModal({ type: "MAGIC", slot, fromBlacksmith: true });
                }}
              >
                <div className="bs-icon">💎</div>
                <div className="bs-title">마법봉인</div>
                <div className={`bs-value-text ${isMagic ? "highlight" : ""}`}>
                  {magicText}
                </div>
              </div>
            )}

            <div
              className="bs-box"
              onClick={() => {
                setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                setActiveModal({ type: "EMBLEM", slot, fromBlacksmith: true });
              }}
            >
              <div className="bs-icon">🛡️</div>
              <div className="bs-title">엠블렘</div>
              <div
                className="bs-value-text"
                style={{
                  display: "flex",
                  gap: "5px",
                  justifyContent: "center",
                  marginTop: "5px",
                }}
              >
                {(() => {
                  const embs = Array.isArray(userStats.emblem[slot])
                    ? userStats.emblem[slot]
                    : [];
                  const equippedEmbs = embs.filter((e) => e);
                  if (equippedEmbs.length === 0) return "설정";
                  return equippedEmbs.map((e, i) => (
                    <div key={i} className="mini-emblem-box">
                      <img
                        src={`${IMAGE_BASE_URL}/emblems/${e.img}.png`}
                        className="mini-emblem-img"
                        alt=""
                        onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                      />
                      <div className="mini-emblem-lv">{e.level}</div>
                    </div>
                  ));
                })()}
              </div>
            </div>
          </div>
        );
      }

      if (type === "REINFORCE") {
        const val = editBuffer.reinforce?.[slot] || 0;
        return (
          <div>
            <div className="grid-5-col">
              {[...Array(20)].map((_, i) => (
                <button
                  key={i + 1}
                  className={`bs-option-btn ${val === i + 1 ? "active" : ""}`}
                  onClick={() => updateBuffer("reinforce", slot, i + 1)}
                >
                  +{i + 1}
                </button>
              ))}
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={handleResetBuffer}
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }
      if (type === "POLISH") {
        const val = editBuffer.polish?.[slot] || 0;
        return (
          <div>
            <div className="grid-5-col">
              {[...Array(10)].map((_, i) => (
                <button
                  key={i + 1}
                  className={`bs-option-btn ${val === i + 1 ? "active" : ""}`}
                  style={{
                    borderColor: i + 1 === 10 ? "red" : "",
                    textShadow: i + 1 === 10 ? "0 0 5px red" : "",
                  }}
                  onClick={() => updateBuffer("polish", slot, i + 1)}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={handleResetBuffer}
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }
      if (type === "ENCHANT") {
        const list = ENCHANT_LIST_BY_SLOT[slot] || [];
        const val = editBuffer.enchant?.[slot] || "선택 안함";
        return (
          <div>
            <div className="enchant-list-wrapper">
              {list.length === 0 ? (
                <div style={{ padding: 20 }}>데이터 없음</div>
              ) : (
                list.map((item, idx) => (
                  <div
                    key={idx}
                    className={`bs-option-btn ${
                      val === item.name ? "active" : ""
                    }`}
                    style={{
                      justifyContent: "flex-start",
                      paddingLeft: "15px",
                    }}
                    onClick={() => updateBuffer("enchant", slot, item.name)}
                  >
                    <span>{item.name}</span>
                  </div>
                ))
              )}
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={handleResetBuffer}
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }
      if (type === "MAGIC") {
        let mGroup =
          slot === "무기"
            ? "무기"
            : ["머리어깨", "상의", "하의", "벨트", "신발"].includes(slot)
            ? "방어구"
            : ["팔찌", "목걸이", "반지"].includes(slot)
            ? "악세서리"
            : "특수장비";
        const options = MAGIC_OPTS_BY_GROUP[mGroup];
        const uVal = editBuffer.magic_unique?.[slot] || "선택 안함";
        const cVal = editBuffer.magic_common?.[slot] || "선택 안함";
        return (
          <div>
            <div className="magic-split-wrapper">
              <div className="magic-col-scroll">
                <div
                  className="magic-section-title"
                  style={{
                    position: "sticky",
                    top: 0,
                    background: "#111",
                    zIndex: 5,
                    paddingBottom: 5,
                  }}
                >
                  고유 옵션
                </div>
                {options?.unique.map((opt) => (
                  <button
                    key={opt.label}
                    className={`bs-option-btn ${
                      uVal === opt.label ? "active" : ""
                    }`}
                    onClick={() =>
                      setEditBuffer((prev) => ({
                        ...prev,
                        magic_unique: {
                          ...prev.magic_unique,
                          [slot]: opt.label,
                        },
                      }))
                    }
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <div className="magic-col-scroll">
                <div
                  className="magic-section-title common"
                  style={{
                    position: "sticky",
                    top: 0,
                    background: "#111",
                    zIndex: 5,
                    paddingBottom: 5,
                  }}
                >
                  일반 옵션
                </div>
                {options?.common.map((opt) => (
                  <button
                    key={opt.label}
                    className={`bs-option-btn ${
                      cVal === opt.label ? "active" : ""
                    }`}
                    onClick={() =>
                      setEditBuffer((prev) => ({
                        ...prev,
                        magic_common: {
                          ...prev.magic_common,
                          [slot]: opt.label,
                        },
                      }))
                    }
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={handleResetBuffer}
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }

      // 6. 엠블렘 (UI/UX 전면 개편)
      if (type === "EMBLEM") {
        const rule = EMBLEM_RULES[slot] || { types: [], slots: 0 };
        const currentEmblems = Array.isArray(editBuffer.emblem?.[slot])
          ? editBuffer.emblem[slot]
          : Array(rule.slots).fill(null);

        const equipEmblem = (newEmblem, isBatch = false) => {
          let nextEmblems = [...currentEmblems];
          if (nextEmblems.length < rule.slots) {
            nextEmblems = [
              ...nextEmblems,
              ...Array(rule.slots - nextEmblems.length).fill(null),
            ];
          }
          if (isBatch) {
            for (let i = 0; i < nextEmblems.length; i++) {
              if (nextEmblems[i] === null) {
                nextEmblems[i] = { ...newEmblem };
              }
            }
          } else {
            const emptyIdx = nextEmblems.findIndex((e) => e === null);
            if (emptyIdx === -1) {
              alert("엠블렘 슬롯이 가득 찼습니다.");
              return;
            }
            nextEmblems[emptyIdx] = { ...newEmblem };
          }
          updateBufferDeep("emblem", -1, nextEmblems);
        };

        const unequipEmblem = (idx) => {
          const nextEmblems = [...currentEmblems];
          nextEmblems[idx] = null;
          updateBufferDeep("emblem", -1, nextEmblems);
        };

        const allowedTypes = rule.types;
        return (
          <div
            style={{ display: "flex", flexDirection: "column", height: "100%" }}
          >
            <div
              style={{
                textAlign: "center",
                fontSize: "0.75rem",
                color: "#888",
                marginBottom: "10px",
              }}
            >
              <span style={{ marginRight: "15px" }}>
                🖱️ 좌클릭: 장착 / 해제
              </span>
              <span style={{ color: "var(--text-gold)" }}>
                ⇧ Shift + 좌클릭: 빈 칸 모두 채우기
              </span>
            </div>
            <div className="emblem-slot-container">
              {[...Array(rule.slots)].map((_, i) => {
                const emblem = currentEmblems[i];
                return (
                  <div
                    key={i}
                    className="emblem-socket-wrapper"
                    onClick={() => emblem && unequipEmblem(i)}
                  >
                    <div
                      className={`emblem-socket ${emblem ? "equipped" : ""}`}
                    >
                      {emblem ? (
                        <>
                          <img
                            src={`${IMAGE_BASE_URL}/emblems/${emblem.img}.png`}
                            className="emblem-img-display"
                            alt=""
                            onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                          />
                          <div className="emblem-lv-overlay">
                            {emblem.level}
                          </div>
                        </>
                      ) : (
                        <div
                          style={{
                            fontSize: "2rem",
                            color: "#333",
                            fontWeight: "bold",
                          }}
                        >
                          +
                        </div>
                      )}
                    </div>
                    <div className="emblem-socket-title">
                      {emblem
                        ? `${emblem.name} ${emblem.level}단계`
                        : "빈 슬롯"}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="rune-selection-area">
              {allowedTypes.map((type) => {
                if (type === "Platinum") {
                  return EMBLEM_DB.Platinum.options.map((opt) => (
                    <div key={opt.id} style={{ marginBottom: "20px" }}>
                      <div
                        className="rune-group-title"
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                        }}
                      >
                        <img
                          src={`${IMAGE_BASE_URL}/emblems/${opt.img}.png`}
                          style={{ width: 24, height: 24 }}
                          alt=""
                        />
                        {opt.name} 엠블렘
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexWrap: "wrap",
                          gap: "6px",
                        }}
                      >
                        {[...Array(15)].map((_, lvIndex) => {
                          const lv = lvIndex + 1;

                          // ★ 수정: 여러 스탯(str, strInc)을 모두 계산해서 computedStats에 담음
                          const computedStats = {};
                          // opt.stats가 존재하는지 확인 (안전장치)
                          if (opt.stats) {
                            Object.keys(opt.stats).forEach((k) => {
                              // 해당 스탯의 레벨별 수치를 가져옴
                              computedStats[k] = opt.stats[k][lv] || 0;
                            });
                          }

                          return (
                            <button
                              key={lv}
                              className="bs-option-btn"
                              style={{
                                width: "45px",
                                padding: "5px 0",
                                fontSize: "0.8rem",
                              }}
                              onClick={(e) =>
                                equipEmblem(
                                  {
                                    name: opt.name,
                                    img: opt.img,
                                    level: lv,
                                    stats: computedStats, // ★ 완성된 복합 스탯 전달
                                  },
                                  e.shiftKey
                                )
                              }
                            >
                              {lv}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ));
                } else {
                  const embData = EMBLEM_DB[type];
                  if (!embData) return null;
                  return (
                    <div key={type} style={{ marginBottom: "20px" }}>
                      <div
                        className="rune-group-title"
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          color:
                            type === "Red"
                              ? "#ff5a6a"
                              : type === "Yellow"
                              ? "#ffcc00"
                              : type === "Green"
                              ? "#00ff00"
                              : "#00ffff",
                        }}
                      >
                        <img
                          src={`${IMAGE_BASE_URL}/emblems/${embData.img}.png`}
                          style={{ width: 24, height: 24 }}
                          alt=""
                        />
                        {embData.name} 엠블렘
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexWrap: "wrap",
                          gap: "6px",
                        }}
                      >
                        {[...Array(15)].map((_, lvIndex) => {
                          const lv = lvIndex + 1;
                          const computedStats = {};
                          Object.keys(embData.stats).forEach((k) => {
                            computedStats[k] = embData.stats[k][lv];
                          });
                          return (
                            <button
                              key={lv}
                              className="bs-option-btn"
                              style={{
                                width: "45px",
                                padding: "5px 0",
                                fontSize: "0.8rem",
                              }}
                              onClick={(e) =>
                                equipEmblem(
                                  {
                                    name: embData.name,
                                    img: embData.img,
                                    level: lv,
                                    stats: computedStats,
                                  },
                                  e.shiftKey
                                )
                              }
                            >
                              {lv}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                }
              })}
            </div>
            <div className="modal-footer-btns">
              <button className="action-btn btn-cancel" onClick={backToMain}>
                취소 (ESC)
              </button>
              <button
                className="action-btn btn-reset"
                onClick={handleResetBuffer}
              >
                초기화
              </button>
              <button className="action-btn btn-apply" onClick={handleApply}>
                적용 (Enter)
              </button>
            </div>
          </div>
        );
      }

      return null;
    };

    return (
      <div
        className="item-picker-modal"
        onClick={
          ["JOURNAL", "BLACKSMITH", "SKILL_RUNE", "AVATAR_MAIN"].includes(type)
            ? close
            : backToMain
        }
        tabIndex={0}
        onKeyDown={handleKeyDown}
        ref={(el) => el && el.focus()}
        style={{ outline: "none" }}
      >
        <div className="picker-content" onClick={(e) => e.stopPropagation()}>
          <div
            className="picker-header"
            style={{
              position: "relative",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {/* 뒤로가기 버튼: 왼쪽 정렬 */}
            {![
              "JOURNAL",
              "BLACKSMITH",
              "SKILL_RUNE",
              "AVATAR_MAIN",
              "JOB_SELECTOR",
              "CLASS_SELECTOR",
            ].includes(type) && (
              <button
                className="picker-close-btn"
                style={{
                  position: "absolute",
                  left: "20px",
                  right: "auto",
                  top: "50%",
                  transform: "translateY(-50%)",
                  fontSize: "1.5rem",
                }}
                onClick={backToMain}
              >
                ⬅
              </button>
            )}

            <h3>{MODAL_TITLE_MAP[type] || type}</h3>

            {/* 닫기 버튼: 오른쪽 정렬 */}
            <button
              className="picker-close-btn"
              style={{
                position: "absolute",
                right: "20px",
                top: "50%",
                transform: "translateY(-50%)",
              }}
              onClick={close}
            >
              ✕
            </button>
          </div>

          <div key={type} className="modal-body-transition">
            {renderContent()}
          </div>
        </div>
      </div>
    );
  };

  // =========================================================
  // [Modal] Bottom Sheet Renderer (장착 해제 기능 추가됨)
  // =========================================================
  const renderBottomSheet = () => {
    if (!activeModal.type) return null;
    const { type, slot } = activeModal;

    const close = () => {
      setActiveModal({ type: null, slot: null });
      setSpecialPickerStep(0);
      setSelectedSpecialSet(null);
      setSearchQuery("");
    };

    // ★ [신규 기능] 장착 해제 핸들러 (모든 옵션 초기화)
    const handleUnequip = () => {
      if (
        !window.confirm(
          `${slot} 장비를 해제하시겠습니까?\n강화 및 모든 옵션이 초기화됩니다.`
        )
      )
        return;

      setUserStats((prev) => {
        const next = JSON.parse(JSON.stringify(prev)); // Deep copy safe

        // 1. 장비 정보 초기화
        next.equipment[slot] = {
          itemId: 0,
          setName: "선택 안함",
          grade: "일반",
        };
        // 익시드 고유옵션 초기화
        if (EXCEED_SLOTS.includes(slot)) next.uniqueOptions[slot] = "선택 안함";

        // 2. 대장간 옵션 전체 초기화
        next.reinforce[slot] = 0;
        if (next.polish) next.polish[slot] = 0;
        next.enchant[slot] = "선택 안함";
        next.magic_unique[slot] = "선택 안함";
        next.magic_common[slot] = "선택 안함";
        if (next.emblem) next.emblem[slot] = { level: 0 }; // or [] 구조에 맞춰 수정

        return next;
      });
      close();
    };

    // 1. 일반 장비 선택 (GEAR_PICKER)
    if (type === "GEAR_PICKER") {
      const isWeapon = slot === "무기";
      const targetDB = isWeapon ? WEAPON_DB : GEAR_DB;

      // ★ [핵심] 무기 필터 적용: isWeapon이면 weaponFilter 상태를 사용
      const groups = getGroupedItems(
        targetDB,
        slot,
        isWeapon ? weaponFilter : null
      );

      const isCurrentlyEquipped = userStats.equipment[slot].itemId !== 0;

      return (
        <div className="bottom-sheet-overlay" onClick={close}>
          <div className="bottom-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-header">
              <span className="sheet-title">{slot} 도감</span>
              <div
                style={{
                  marginLeft: "auto",
                  display: "flex",
                  alignItems: "center",
                  gap: "15px",
                }}
              >
                {isCurrentlyEquipped && (
                  <button
                    onClick={handleUnequip}
                    style={{
                      background: "#2a1515",
                      border: "1px solid #5a2525",
                      color: "#ff6b6b",
                      padding: "6px 12px",
                      borderRadius: "6px",
                      cursor: "pointer",
                      fontWeight: "bold",
                      fontSize: "0.85rem",
                    }}
                  >
                    장착 해제
                  </button>
                )}
                <button className="sheet-close" onClick={close}>
                  ✕
                </button>
              </div>
            </div>

            <div className="sheet-body">
              {/* ★ [New] 무기 타입 탭 (무기 슬롯일 때만 표시) */}
              {isWeapon && (
                <div className="weapon-tab-container">
                  {(WEAPON_TYPES[userStats.character.baseJob] || []).map(
                    (type) => (
                      <button
                        key={type}
                        className={`weapon-tab-btn ${
                          weaponFilter === type ? "active" : ""
                        }`}
                        onClick={() => setWeaponFilter(type)}
                      >
                        {type}
                      </button>
                    )
                  )}
                </div>
              )}

              <div className="card-grid">
                {groups.map(({ baseItem, variants }) => {
                  // ★ [수정] 이름 정제 로직 변경
                  // 무기가 아니고(slot !== "무기") 콜론이 있을 때만 접두사를 자릅니다.
                  // 무기는 원본 이름 그대로("뇌검 : 고룬") 사용합니다.
                  const cleanName =
                    slot !== "무기" && baseItem.name.includes(":")
                      ? baseItem.name.split(":")[1].trim()
                      : baseItem.name;

                  return (
                    <div key={baseItem.id} className="item-card">
                      <div className="card-thumb">
                        <img
                          src={GET_ITEM_ICON(baseItem.name, slot)}
                          alt=""
                          onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = PLACEHOLDER_IMG;
                          }}
                        />
                      </div>
                      <div className="card-info">
                        <div className="card-set">
                          {baseItem.setName || "단일"}
                        </div>

                        {/* 수정된 cleanName 표시 */}
                        <div
                          className="card-name"
                          style={{ color: getGradeColor(baseItem.grade) }}
                        >
                          {cleanName}
                        </div>
                        <div className="grade-chips">
                          {variants.map((v) => {
                            const rawGrade = v.grade || "";
                            let label = "일반";
                            if (rawGrade.includes(":"))
                              label = rawGrade.split(":")[1].trim();
                            else if (rawGrade.includes("익시드"))
                              label = "익시드";
                            else if (rawGrade.includes("유니크"))
                              label = "유니크";
                            else if (rawGrade.includes("레어")) label = "레어";

                            let colorVar = "var(--grade-epic)";
                            let bgStyle = "transparent";
                            if (rawGrade.includes("익시드")) {
                              colorVar = "var(--grade-exceed)";
                              bgStyle = "rgba(0, 255, 255, 0.08)";
                            } else if (rawGrade.includes("유니크")) {
                              colorVar = "var(--grade-unique)";
                            } else if (rawGrade.includes("레어")) {
                              colorVar = "var(--grade-rare)";
                            }

                            return (
                              <button
                                key={v.id}
                                className="grade-chip"
                                style={{
                                  borderColor: colorVar,
                                  color: colorVar,
                                  background: bgStyle,
                                }}
                                onClick={(e) => {
                                  e.stopPropagation();

                                  // ★ 무기 선택 시: 선택한 무기 타입을 userStats에 저장 (계산기 로직 호환성 위해)
                                  if (isWeapon) {
                                    updateStat(
                                      "character",
                                      "weaponType",
                                      weaponFilter
                                    );
                                  }

                                  handleGearUpdate(slot, v.id);
                                  close();
                                }}
                              >
                                {label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              {groups.length === 0 && (
                <div
                  style={{ padding: 40, textAlign: "center", color: "#666" }}
                >
                  해당 타입의 아이템이 없습니다.
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    // 2. 특수 장비 선택 (SPECIAL_PICKER)
    if (type === "SPECIAL_PICKER") {
      const sets = getSpecialSets(GEAR_DB, slot);
      const isCurrentlyEquipped = userStats.equipment[slot].itemId !== 0;

      return (
        <div className="bottom-sheet-overlay" onClick={close}>
          <div className="bottom-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-header">
              <span className="sheet-title">
                {specialPickerStep === 0
                  ? `${slot} 선택`
                  : `${selectedSpecialSet?.setName || slot}`}
              </span>

              <div
                style={{
                  marginLeft: "auto",
                  display: "flex",
                  alignItems: "center",
                  gap: "15px",
                }}
              >
                {/* 뒤로가기 버튼 (스텝 1일 때만) */}
                {specialPickerStep === 1 && (
                  <button
                    onClick={() => setSpecialPickerStep(0)}
                    style={{
                      background: "none",
                      border: "none",
                      color: "#aaa",
                      cursor: "pointer",
                      fontSize: "1.2rem",
                      marginRight: "10px",
                    }}
                  >
                    ⬅
                  </button>
                )}
                {/* ★ 장착 해제 버튼 */}
                {isCurrentlyEquipped && (
                  <button
                    onClick={handleUnequip}
                    style={{
                      background: "#2a1515",
                      border: "1px solid #5a2525",
                      color: "#ff6b6b",
                      padding: "6px 12px",
                      borderRadius: "6px",
                      cursor: "pointer",
                      fontWeight: "bold",
                      fontSize: "0.85rem",
                    }}
                  >
                    해제
                  </button>
                )}
                <button className="sheet-close" onClick={close}>
                  ✕
                </button>
              </div>
            </div>

            <div className="sheet-body">
              {specialPickerStep === 0 ? (
                // Step 1: 세트 목록
                <div className="card-grid">
                  {sets.map((set) => {
                    const sortedItems = [...set.items].sort(
                      (a, b) => a.id - b.id
                    );
                    let repItem = sortedItems.find(
                      (it) => !it.name.includes("[") && !it.name.includes(":")
                    );
                    if (!repItem) repItem = sortedItems[0];
                    const summary = getSetOptionSummary(repItem.stats);
                    const optionColor = summary.isLowTier
                      ? "var(--grade-unique)"
                      : "var(--text-gold)";

                    if (set.items.length === 1) {
                      const item = set.items[0];
                      return (
                        <div
                          key={item.id}
                          className="item-card"
                          onClick={() => {
                            handleGearUpdate(slot, item.id);
                            close();
                          }}
                        >
                          <div className="card-thumb">
                            <img
                              src={GET_ITEM_ICON(item.name, slot)}
                              alt=""
                              onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = PLACEHOLDER_IMG;
                              }}
                            />
                          </div>
                          <div className="card-info">
                            <div
                              className="card-name"
                              style={{ color: getGradeColor(item.grade) }}
                            >
                              {item.name}
                            </div>
                            <div
                              className="card-set"
                              style={{
                                marginTop: "4px",
                                fontSize: "0.75rem",
                                lineHeight: "1.4",
                              }}
                            >
                              <span
                                style={{ color: "#888", marginRight: "4px" }}
                              >
                                주요 옵션
                              </span>
                              <span style={{ color: optionColor }}>
                                {summary.text}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    } else {
                      return (
                        <div
                          key={set.setCode}
                          className="item-card"
                          onClick={() => {
                            setSelectedSpecialSet(set);
                            setSpecialPickerStep(1);
                          }}
                        >
                          <div className="card-thumb">
                            <img
                              src={GET_ITEM_ICON(repItem.name, slot)}
                              alt=""
                              onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = PLACEHOLDER_IMG;
                              }}
                            />
                          </div>
                          <div className="card-info">
                            <div className="card-name">{set.setName}</div>
                            <div
                              className="card-set"
                              style={{
                                marginTop: "4px",
                                fontSize: "0.75rem",
                                lineHeight: "1.4",
                              }}
                            >
                              <span
                                style={{ color: "#888", marginRight: "4px" }}
                              >
                                주요 옵션
                              </span>
                              <span style={{ color: optionColor }}>
                                {summary.text}
                              </span>
                            </div>
                          </div>
                          <div style={{ color: "#888", fontSize: "1.2rem" }}>
                            ›
                          </div>
                        </div>
                      );
                    }
                  })}
                </div>
              ) : (
                // Step 2: 아이템 목록
                <div className="card-grid">
                  {selectedSpecialSet.items
                    .sort(
                      (a, b) =>
                        a.stats.itemCode1 - b.stats.itemCode1 || b.id - a.id
                    )
                    .map((item) => (
                      <div
                        key={item.id}
                        className="item-card"
                        onClick={() => {
                          handleGearUpdate(slot, item.id);
                          close();
                        }}
                      >
                        <div className="card-thumb">
                          <img
                            src={GET_ITEM_ICON(item.name, slot)}
                            alt=""
                            onError={(e) => {
                              e.target.onerror = null;
                              e.target.src = PLACEHOLDER_IMG;
                            }}
                          />
                        </div>
                        <div className="card-info">
                          <div
                            className="card-name"
                            style={{ color: getGradeColor(item.grade) }}
                          >
                            {item.name}
                          </div>
                          <div className="card-set">{item.grade}</div>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    if (type === "RUNE") {
      const { special, general } = userStats.skillRunes;
      const totalSpecial = special.gaho + special.jihe + special.waegok;
      const currentTotal =
        totalSpecial + general.reduce((acc, curr) => acc + curr.count, 0);

      const handleSpecialChange = (key, val) => {
        const diff = val - special[key];
        if (currentTotal + diff > 20)
          return alert("스킬룬은 20개까지만 장착 가능합니다.");
        updateStat("skillRunes", "special", { ...special, [key]: val });
      };

      const addGeneralRune = () => {
        if (currentTotal >= 20) return alert("스킬룬 가득 참");
        const tEl = document.getElementById("runeType");
        const gEl = document.getElementById("runeGrade");
        const lEl = document.getElementById("runeLevel");
        if (!tEl || !gEl || !lEl) return;

        const newRune = {
          type: tEl.value,
          grade: Number(gEl.value),
          level: Number(lEl.value),
          count: 1,
        };
        const existingIdx = general.findIndex(
          (r) =>
            r.type === newRune.type &&
            r.grade === newRune.grade &&
            r.level === newRune.level
        );
        let nextGen = [...general];
        if (existingIdx >= 0) nextGen[existingIdx].count++;
        else nextGen.push(newRune);
        updateStat("skillRunes", "general", nextGen);
      };

      const removeGeneralRune = (idx) => {
        let nextGen = [...general];
        if (nextGen[idx].count > 1) nextGen[idx].count--;
        else nextGen.splice(idx, 1);
        updateStat("skillRunes", "general", nextGen);
      };

      return (
        <div className="bottom-sheet-overlay" onClick={close}>
          <div
            className="bottom-sheet"
            onClick={(e) => e.stopPropagation()}
            style={{ height: "650px" }}
          >
            <div className="sheet-header">
              <span className="sheet-title">스킬룬 설정</span>
              <button className="sheet-close" onClick={close}>
                ✕
              </button>
            </div>
            <div
              className="sheet-body"
              style={{ display: "flex", flexDirection: "column", gap: "20px" }}
            >
              <div style={{ textAlign: "right", color: "#aaa" }}>
                장착: {currentTotal} / 20
              </div>
              <div className="journal-section">
                <span className="journal-label">특수 스킬룬</span>
                <div
                  style={{
                    display: "flex",
                    gap: "10px",
                    justifyContent: "space-around",
                  }}
                >
                  {["gaho", "jihe", "waegok"].map((k) => (
                    <div key={k} style={{ textAlign: "center" }}>
                      <div
                        style={{
                          marginBottom: "5px",
                          fontSize: "0.8rem",
                          color: "#00ffff",
                        }}
                      >
                        {k === "gaho" ? "가호" : k === "jihe" ? "지혜" : "왜곡"}
                      </div>
                      <select
                        className="grade-select"
                        style={{ width: "60px" }}
                        value={special[k]}
                        onChange={(e) =>
                          handleSpecialChange(k, Number(e.target.value))
                        }
                      >
                        {[...Array(RUNE_CONSTANTS.special.max[k] + 1)].map(
                          (_, i) => (
                            <option key={i} value={i}>
                              {i}
                            </option>
                          )
                        )}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
              <div className="journal-section">
                <span className="journal-label">일반 스킬룬 추가</span>
                <div
                  style={{ display: "flex", gap: "5px", marginBottom: "10px" }}
                >
                  <select
                    id="runeType"
                    className="dark-select"
                    style={{ flex: 1 }}
                    onChange={(e) => {
                      const lvSelect = document.getElementById("runeLevel");
                      const levels =
                        RUNE_CONSTANTS.general.levels[e.target.value];
                      lvSelect.innerHTML = levels
                        .map((lv) => `<option value="${lv}">${lv}Lv</option>`)
                        .join("");
                    }}
                  >
                    {RUNE_CONSTANTS.general.types.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  <select
                    id="runeGrade"
                    className="dark-select"
                    style={{ width: "70px" }}
                  >
                    <option value="3">3레벨</option>
                    <option value="4">4레벨</option>
                  </select>
                  <select
                    id="runeLevel"
                    className="dark-select"
                    style={{ width: "70px" }}
                  >
                    {RUNE_CONSTANTS.general.levels["각성"].map((lv) => (
                      <option key={lv} value={lv}>
                        {lv}Lv
                      </option>
                    ))}
                  </select>
                  <button
                    className="inner-btn active"
                    style={{ width: "50px" }}
                    onClick={addGeneralRune}
                  >
                    추가
                  </button>
                </div>
                <div
                  style={{
                    maxHeight: "200px",
                    overflowY: "auto",
                    background: "#111",
                    borderRadius: "4px",
                    padding: "5px",
                  }}
                >
                  {general.map((rune, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        padding: "5px",
                        borderBottom: "1px solid #333",
                      }}
                    >
                      <span
                        style={{
                          color: rune.grade === 4 ? "#ff77ff" : "#00ffff",
                          fontSize: "0.85rem",
                        }}
                      >
                        [{rune.type}] {rune.grade}레벨 (Lv.{rune.level}) x
                        {rune.count}
                      </span>
                      <button
                        style={{
                          background: "none",
                          border: "none",
                          color: "#ff5a6a",
                          cursor: "pointer",
                        }}
                        onClick={() => removeGeneralRune(idx)}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
  };

  // [App.js] 하단 종합 능력치 패널 렌더링 함수 (v2.0: 상세 분류 및 로직 개선)
  const renderBottomStatPanel = () => {
    // 헬퍼: 값 포맷팅
    const fmt = (val, isPercent = false) => {
      if (val === undefined || val === null) return 0;
      const num = Number(val);
      const display = Number.isInteger(num) ? num : num.toFixed(1);
      return `${display.toLocaleString()}${isPercent ? "%" : ""}`;
    };

    // 헬퍼: 속성 부여 텍스트 & 색상 변환
    const renderElInflict = (val) => {
      if (!val) return <span style={{ color: "#555" }}>없음</span>;
      const map = {
        1: { text: "화속성 공격", color: "#ff5a6a" },
        2: { text: "수속성 공격", color: "#aaddff" },
        3: { text: "명속성 공격", color: "#ffffaa" },
        4: { text: "암속성 공격", color: "#aa55ff" },
      };
      const info = map[val];
      return (
        <span style={{ color: info.color, fontWeight: "bold" }}>
          {info ? info.text : "없음"}
        </span>
      );
    };

    // --- [전처리] 표시용 데이터 가공 ---
    // finalStats는 원본을 유지하고, 보여줄 때만 계산해서 보여줍니다.

    // 1. 최고 속성 판별 (가장 높은 속성 강화 수치 찾기)
    const { fireEle, waterEle, lightEle, darkEle, highestEleAddDmg } =
      finalStats;
    const eleValues = {
      fire: fireEle,
      water: waterEle,
      light: lightEle,
      dark: darkEle,
    };
    const maxEleKey = Object.keys(eleValues).reduce((a, b) =>
      eleValues[a] >= eleValues[b] ? a : b
    );

    // 2. 속성 추가 데미지 합산 (최고 속성 추뎀을 해당 속성에 더해서 표시)
    // (기존 finalStats에는 fireAddDmg 등이 들어있음)
    const displayFireAdd =
      finalStats.fireAddDmg + (maxEleKey === "fire" ? highestEleAddDmg : 0);
    const displayWaterAdd =
      finalStats.waterAddDmg + (maxEleKey === "water" ? highestEleAddDmg : 0);
    const displayLightAdd =
      finalStats.lightAddDmg + (maxEleKey === "light" ? highestEleAddDmg : 0);
    const displayDarkAdd =
      finalStats.darkAddDmg + (maxEleKey === "dark" ? highestEleAddDmg : 0);

    // 3. 스킬 데이터 추출 (존재하는 것만)
    const skillData = finalStats.skill || { dmg: {}, lv: {}, cdr: {} };
    // 레벨 키 정렬 (lv10, lv15 ... 순서)
    const getSortedKeys = (obj) =>
      Object.keys(obj).sort(
        (a, b) => Number(a.replace("lv", "")) - Number(b.replace("lv", ""))
      );

    return (
      <div className="bottom-stat-panel">
        {/* 1. 기본 스탯 (Base Stats) */}
        <div className="stat-col">
          <div
            className="stat-group-header"
            data-tooltip={`캐릭터의 가장 기초적인 강함을 나타내는 수치들입니다.\n장비 착용 시 가장 먼저 확인하는 1차적인 정보들입니다.`}
          >
            기본 스탯
          </div>

          {/* ★ [수정] 장비 포인트 상세 표시 (구간별 색상 적용) */}
          <div
            className="stat-row highlight"
            style={{
              marginBottom: "10px",
              borderBottom: "1px solid #444",
              display: "block",
              paddingBottom: "8px",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "4px",
              }}
            >
              <span>총 장비 포인트</span>
              <span
                style={{ color: "var(--grade-exceed)", fontSize: "1.1rem" }}
              >
                {totalGearPoint.toLocaleString()}
              </span>
            </div>

            {/* 세부 내역 및 색상 로직 */}
            {(() => {
              const armorP = finalStats.gpDetails?.armor || 0;
              const accP = finalStats.gpDetails?.acc || 0;
              const specP = finalStats.gpDetails?.special || 0;

              // 색상 결정 헬퍼
              const getGPColor = (val, type) => {
                if (type === "armor") {
                  if (val >= 5500) return "var(--grade-exceed)"; // 익시드
                  if (val >= 3000) return "var(--grade-epic)"; // 에픽
                  if (val >= 1500) return "var(--grade-unique)"; // 유니크
                  if (val >= 250) return "var(--grade-rare)"; // 레어
                } else {
                  // 장신구 & 특수장비
                  if (val >= 3500) return "var(--grade-exceed)"; // 익시드
                  if (val >= 2000) return "var(--grade-epic)"; // 에픽
                  if (val >= 1000) return "var(--grade-unique)"; // 유니크
                  if (val >= 250) return "var(--grade-rare)"; // 레어
                }
                return "#fff"; // 0~249 (흰색)
              };

              return (
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    fontSize: "0.75rem",
                    color: "#888",
                  }}
                >
                  <span>
                    방어구{" "}
                    <span
                      style={{
                        color: getGPColor(armorP, "armor"),
                        fontWeight: "bold",
                      }}
                    >
                      {armorP.toLocaleString()}
                    </span>
                  </span>
                  <span>
                    장신구{" "}
                    <span
                      style={{
                        color: getGPColor(accP, "acc"),
                        fontWeight: "bold",
                      }}
                    >
                      {accP.toLocaleString()}
                    </span>
                  </span>
                  <span>
                    특수{" "}
                    <span
                      style={{
                        color: getGPColor(specP, "spec"),
                        fontWeight: "bold",
                      }}
                    >
                      {specP.toLocaleString()}
                    </span>
                  </span>
                </div>
              );
            })()}
          </div>

          <div className="stat-row">
            <span>힘</span>
            <span>{fmt(finalStats.str)}</span>
          </div>
          <div className="stat-row">
            <span>지능</span>
            <span>{fmt(finalStats.int)}</span>
          </div>
          <div className="stat-row">
            <span>힘(%)</span>
            <span>{fmt(finalStats.strInc, true)}</span>
          </div>
          <div className="stat-row">
            <span>지능(%)</span>
            <span>{fmt(finalStats.intInc, true)}</span>
          </div>

          <div className="stat-row" style={{ marginTop: "5px" }}>
            <span>물리 공격력</span>
            <span>{fmt(finalStats.physAtk)}</span>
          </div>
          <div className="stat-row">
            <span>마법 공격력</span>
            <span>{fmt(finalStats.magAtk)}</span>
          </div>
          <div className="stat-row">
            <span>물리 공격력(%)</span>
            <span>{fmt(finalStats.physAtkInc, true)}</span>
          </div>
          <div className="stat-row">
            <span>마법 공격력(%)</span>
            <span>{fmt(finalStats.magAtkInc, true)}</span>
          </div>

          <div className="stat-row" style={{ marginTop: "5px" }}>
            <span>물리 크리티컬</span>
            <span>{fmt(finalStats.physCrit)}</span>
          </div>
          <div className="stat-row">
            <span>마법 크리티컬</span>
            <span>{fmt(finalStats.magCrit)}</span>
          </div>
          <div className="stat-row highlight">
            <span>물리 크리티컬 확률(%)</span>
            <span>{fmt(finalStats.physCritRate, true)}</span>
          </div>
          <div className="stat-row highlight">
            <span>마법 크리티컬 확률(%)</span>
            <span>{fmt(finalStats.magCritRate, true)}</span>
          </div>
        </div>

        {/* 2. 공격 효율 (Damage & Skill) */}
        <div className="stat-col">
          <div
            className="stat-group-header"
            data-tooltip={`실질적인 데미지 딜링에 관여하는 '증가' 옵션들입니다.`}
          >
            공격 효율
          </div>

          {/* 상단: DAMAGE */}
          <div className="stat-sub-group">
            <div className="sub-group-title">DAMAGE</div>
            <div className="stat-row highlight">
              <span>데미지 증가(%)</span>
              <span>{fmt(finalStats.dmgInc, true)}</span>
            </div>
            <div className="stat-row highlight">
              <span>공격 시 추가 데미지(%)</span>
              <span>{fmt(finalStats.addDmg, true)}</span>
            </div>
            <div className="stat-row highlight">
              <span>크리티컬 데미지(%)</span>
              <span>{fmt(finalStats.critDmgInc, true)}</span>
            </div>
            <div className="stat-row highlight">
              <span>최종 데미지(%)</span>
              <span>{fmt(finalStats.finalDmg, true)}</span>
            </div>
            <div className="stat-row">
              <span>모든 타입 피해(%)</span>
              <span>{fmt(finalStats.allTypeDmg, true)}</span>
            </div>
            <div className="stat-row">
              <span>카운터 데미지 증가(%)</span>
              <span>{fmt(finalStats.counterDmgInc, true)}</span>
            </div>
            <div className="stat-row">
              <span>카운터 추가 데미지(%)</span>
              <span>{fmt(finalStats.counterAddDmg, true)}</span>
            </div>
            <div className="stat-row" style={{ color: "#ff5a6a" }}>
              <span>적 방어력 감소(%)</span>
              <span>{fmt(finalStats.defShred, true)}</span>
            </div>
          </div>

          {/* 하단: SKILL */}
          <div className="stat-sub-group" style={{ borderBottom: "none" }}>
            <div
              className="sub-group-title"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              SKILL
              <span
                style={{
                  fontSize: "0.6rem",
                  color: "#888",
                  fontWeight: "normal",
                }}
              >
                *스킬공격력(%) x 레벨별(%) 곱연산
              </span>
            </div>

            {/* 공통 스증 (여기로 이동) */}
            <div className="stat-row highlight" style={{ marginBottom: "5px" }}>
              <span>스킬 공격력(%)</span>
              <span>{fmt(finalStats.skillAtkInc, true)}</span>
            </div>

            {/* 동적 스킬 데이터 표시 */}
            {/* 1. 스킬 공격력 (개별) */}
            {getSortedKeys(skillData.dmg).map((key) => {
              const val = skillData.dmg[key];
              if (!val) return null;
              const lv = key.replace("lv", "");
              return (
                <div key={`sd-${key}`} className="stat-row">
                  <span>스킬 공격력 {lv}Lv</span>
                  <span>{fmt(val, true)}</span>
                </div>
              );
            })}

            {/* 2. 스킬 레벨 */}
            {getSortedKeys(skillData.lv).map((key) => {
              const val = skillData.lv[key];
              if (!val) return null;
              const lv = key.replace("lv", "");
              return (
                <div key={`sl-${key}`} className="stat-row">
                  <span>스킬 레벨 {lv}Lv</span>
                  <span style={{ color: "#00ff00" }}>+{val}</span>
                </div>
              );
            })}

            {/* 3. 쿨타임 감소 */}
            {getSortedKeys(skillData.cdr).map((key) => {
              const val = skillData.cdr[key];
              if (!val) return null;
              const lv = key.replace("lv", "");
              return (
                <div key={`sc-${key}`} className="stat-row">
                  <span>스킬 쿨타임 감소 {lv}Lv</span>
                  <span style={{ color: "#aaddff" }}>{fmt(val, true)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. 속성 및 상태이상 */}
        <div className="stat-col">
          <div
            className="stat-group-header"
            data-tooltip={`공격의 '속성'과 상태이상 데미지를 결정짓는 그룹입니다.`}
          >
            속성 & 상태이상
          </div>

          {/* 상단: 속성 */}
          <div className="stat-sub-group">
            <div className="sub-group-title">ELEMENT</div>
            <div className="stat-row">
              <span>속성 부여</span>
              <span style={{ fontSize: "0.8rem" }}>
                {renderElInflict(finalStats.elInflict1)}
                {finalStats.elInflict2 ? (
                  <>, {renderElInflict(finalStats.elInflict2)}</>
                ) : (
                  ""
                )}
              </span>
            </div>
            <div className="stat-row">
              <span>화속성 강화</span>
              <span>{fmt(finalStats.fireEle)}</span>
            </div>
            <div className="stat-row">
              <span>수속성 강화</span>
              <span>{fmt(finalStats.waterEle)}</span>
            </div>
            <div className="stat-row">
              <span>명속성 강화</span>
              <span>{fmt(finalStats.lightEle)}</span>
            </div>
            <div className="stat-row">
              <span>암속성 강화</span>
              <span>{fmt(finalStats.darkEle)}</span>
            </div>
            {/* 모속강은 이미 위 4개에 합산되었으므로 표시하지 않음 */}

            <div className="stat-row">
              <span>화속성 추가 데미지(%)</span>
              <span>{fmt(displayFireAdd, true)}</span>
            </div>
            <div className="stat-row">
              <span>수속성 추가 데미지(%)</span>
              <span>{fmt(displayWaterAdd, true)}</span>
            </div>
            <div className="stat-row">
              <span>명속성 추가 데미지(%)</span>
              <span>{fmt(displayLightAdd, true)}</span>
            </div>
            <div className="stat-row">
              <span>암속성 추가 데미지(%)</span>
              <span>{fmt(displayDarkAdd, true)}</span>
            </div>
            {/* 최고속성 추뎀은 위 4개 중 하나에 합산되었으므로 표시하지 않음 */}
          </div>

          {/* 하단: 상태이상 */}
          <div className="stat-sub-group" style={{ borderBottom: "none" }}>
            <div className="sub-group-title">STATUS</div>
            <div className="stat-row">
              <span>공격 시 출혈 데미지(%)</span>
              <span>{fmt(finalStats.bleedDmg, true)}</span>
            </div>
            <div className="stat-row">
              <span>공격 시 중독 데미지(%)</span>
              <span>{fmt(finalStats.poisonDmg, true)}</span>
            </div>
            <div className="stat-row">
              <span>공격 시 화상 데미지(%)</span>
              <span>{fmt(finalStats.burnDmg, true)}</span>
            </div>
            <div className="stat-row">
              <span>공격 시 감전 데미지(%)</span>
              <span>{fmt(finalStats.shockDmg, true)}</span>
            </div>
            <div className="stat-row">
              <span>출혈 데미지 증가(%)</span>
              <span>{fmt(finalStats.bleedInc, true)}</span>
            </div>
            <div className="stat-row">
              <span>중독 데미지 증가(%)</span>
              <span>{fmt(finalStats.poisonInc, true)}</span>
            </div>
            <div className="stat-row">
              <span>화상 데미지 증가(%)</span>
              <span>{fmt(finalStats.burnInc, true)}</span>
            </div>
            <div className="stat-row">
              <span>감전 데미지 증가(%)</span>
              <span>{fmt(finalStats.shockInc, true)}</span>
            </div>
          </div>
        </div>

        {/* 4. 생존 및 유틸 */}
        <div className="stat-col">
          <div
            className="stat-group-header"
            data-tooltip={`캐릭터의 생존력(방어, 체력)과 쾌적함(속도, 적중)을 담당합니다.`}
          >
            생존 & 유틸
          </div>
          <div className="stat-row">
            <span>HP MAX</span>
            <span>{fmt(finalStats.hpMax)}</span>
          </div>
          <div className="stat-row">
            <span>MP MAX</span>
            <span>{fmt(finalStats.mpMax)}</span>
          </div>
          <div className="stat-row">
            <span>물리 방어력</span>
            <span>{fmt(finalStats.physDef)}</span>
          </div>
          <div className="stat-row">
            <span>마법 방어력</span>
            <span>{fmt(finalStats.magDef)}</span>
          </div>
          <div className="stat-row">
            <span>정신력</span>
            <span>{fmt(finalStats.spirit)}</span>
          </div>
          <div className="stat-row">
            <span>물리 데미지 감소(%)</span>
            <span>{fmt(finalStats.physDmgRed, true)}</span>
          </div>
          <div className="stat-row">
            <span>마법 데미지 감소(%)</span>
            <span>{fmt(finalStats.magDmgRed, true)}</span>
          </div>

          <div className="stat-row" style={{ marginTop: "10px" }}>
            <span>화속성 저항</span>
            <span>{fmt(finalStats.fireRes)}</span>
          </div>
          <div className="stat-row">
            <span>수속성 저항</span>
            <span>{fmt(finalStats.waterRes)}</span>
          </div>
          <div className="stat-row">
            <span>명속성 저항</span>
            <span>{fmt(finalStats.lightRes)}</span>
          </div>
          <div className="stat-row">
            <span>암속성 저항</span>
            <span>{fmt(finalStats.darkRes)}</span>
          </div>

          <div className="stat-row highlight" style={{ marginTop: "10px" }}>
            <span>공격 속도(%)</span>
            <span>{fmt(finalStats.atkSpeed, true)}</span>
          </div>
          <div className="stat-row highlight">
            <span>캐스팅 속도(%)</span>
            <span>{fmt(finalStats.castSpeed, true)}</span>
          </div>
          <div className="stat-row highlight">
            <span>이동 속도(%)</span>
            <span>{fmt(finalStats.moveSpeed, true)}</span>
          </div>

          <div className="stat-row">
            <span>적중</span>
            <span>{fmt(finalStats.hit)}</span>
          </div>
          <div className="stat-row">
            <span>적중 확률(%)</span>
            <span>{fmt(finalStats.hitRate, true)}</span>
          </div>
          <div className="stat-row">
            <span>회피</span>
            <span>{fmt(finalStats.evasion)}</span>
          </div>
          <div className="stat-row">
            <span>회피 확률(%)</span>
            <span>{fmt(finalStats.evasionRate, true)}</span>
          </div>
          <div className="stat-row highlight">
            <span>슈퍼아머</span>
            <span style={{ color: finalStats.superArmor ? "#00ff00" : "#555" }}>
              {finalStats.superArmor ? "적용" : "미적용"}
            </span>
          </div>
        </div>

        {/* 5. 최종 결과 */}
        <div className="stat-col result-col-inner">
          <div
            className="stat-group-header"
            data-tooltip="최종 계산된 데미지 결과입니다."
          >
            데미지 분석
          </div>

          {/* 스킬 데미지 */}
          <div className="dmg-box">
            <div className="dmg-label">스킬 데미지</div>
            <div className="dmg-val">
              {finalDamageInfo.normal.toLocaleString()}
            </div>
          </div>

          {/* + 기호 */}
          <div className="plus-sign">+</div>

          {/* 상태이상 데미지 */}
          <div className="dmg-box">
            <div className="dmg-label">상태이상 데미지</div>
            <div className="dmg-val" style={{ color: "#ff77ff" }}>
              {finalDamageInfo.status.toLocaleString()}
            </div>
          </div>

          {/* 총 합산 */}
          <div className="total-dmg-box">
            <div className="total-label">총 합산 데미지</div>
            <div className="total-val">
              {finalDamageInfo.total.toLocaleString()}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // =========================================================
  // [5] Main Render
  // =========================================================
  const renderCalculatorPage = () => {
    // 1. 수련일지 데이터 (안전장치 포함)
    const {
      concentrator = 0,
      hopae = 0,
      breakthrough = 0,
      sealMain = "",
      sealSub = "",
    } = userStats.training || {};

    // ★ 수정: 성안의 봉인(sealMain, sealSub)이 하나라도 있으면 활성 상태로 간주
    const isJournalActive =
      concentrator > 0 ||
      hopae > 0 ||
      breakthrough > 0 ||
      sealMain !== "" ||
      sealSub !== "";
    const journalText = `마력${concentrator} / 호패${hopae} / 돌파${breakthrough}`;

    // 2. 스킬룬 데이터 & 요약 텍스트 생성
    const { slots } = userStats.skillRunes || { slots: [] };
    const totalRunes = slots.filter((r) => r).length;

    // 룬 카운팅 (종류/등급/레벨별로 묶기)
    const runeSummaryMap = new Map();
    slots.forEach((r) => {
      if (!r) return;
      let key = "";
      let displayName = "";

      if (r.type === "special") {
        // 특수 룬: 이름만 사용 (예: "가호")
        const coreName = r.name.replace("의 룬", "");
        key = coreName;
        displayName = coreName;
      } else {
        // 일반 룬: 이름 + 등급 + 레벨 (예: "각성IV[65]")
        const coreName = r.name.replace("의 룬", "");
        const gradeRoman = r.grade === 3 ? "III" : "IV";
        key = `${coreName}${gradeRoman}[${r.level}]`;
        displayName = key;
      }

      const currentVal = runeSummaryMap.get(key) || {
        name: displayName,
        count: 0,
      };
      runeSummaryMap.set(key, {
        name: displayName,
        count: currentVal.count + 1,
      });
    });

    // 텍스트로 변환 (예: "가호 2 / 지혜 1 / 각성IV[65] 3")
    const runeSummaryText = Array.from(runeSummaryMap.values())
      .map((item) => `${item.name} ${item.count}`)
      .join(" / ");

    // ★ [3. 누락된 부분 복구] 아바타 데이터
    const { set: avatarSet } = userStats.avatarSettings || { set: "없음" };

    const renderStatGroup = (title, items) => (
      <div className="stat-group">
        <div className="stat-category-header">{title}</div>
        {items.map(({ label, key, isPercent, isHighlight }) => {
          let val = finalStats[key] || 0;
          if (typeof val === "number" && !Number.isInteger(val))
            val = val.toFixed(1);
          return (
            <div
              key={key}
              className={`stat-detail-row ${
                isHighlight ? "stat-highlight" : ""
              }`}
            >
              <span className="stat-detail-label">{label}</span>
              <span className="stat-detail-val">
                {Number(val).toLocaleString()}
                {isPercent ? "%" : ""}
              </span>
            </div>
          );
        })}
      </div>
    );

    // ★ [추가] 캐릭터 전직 정보 (여기서 선언해야 아래에서 subJob 변수를 쓸 수 있습니다)
    const { subJob } = userStats.character;

    // [App.js] renderCalculatorPage 리턴 부분 (최종 레이아웃)
    return (
      <div className="calc-game-container">
        {/* 상단 섹션 (내실 / 장비 / 캐릭터 / 장비 / 세트효과) - Flex Row */}
        <div
          style={{
            display: "flex",
            width: "100%",
            justifyContent: "center",
            gap: "55px",

            alignItems: "flex-start",
            flexWrap: "wrap",
          }}
        >
          {/* 1. 좌측 컨트롤 (내실 + 스킬) */}
          <div className="control-column">
            {/* 1. 내실 설정 타이틀 */}
            <div className="panel-title">내실 설정</div>

            <div className="naesil-control-box">
              {/* 1-1. 수련일지 */}
              <div
                className={`naesil-btn ${isJournalActive ? "active" : ""}`}
                onClick={() => setActiveModal({ type: "JOURNAL", slot: null })}
                style={{
                  height: "auto",
                  minHeight: "60px",
                  padding: "10px",
                  flexDirection: "row",
                }}
              >
                <img
                  src={`${IMAGE_BASE_URL}/icons/수련일지.png`}
                  className="naesil-btn-img"
                  alt="수련"
                  onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                />
                <div className="naesil-btn-info">
                  <span
                    className="naesil-btn-label"
                    style={{ marginBottom: "2px" }}
                  >
                    수련일지
                  </span>
                  {isJournalActive ? (
                    <>
                      <span className="naesil-btn-val small-text">{`마력 ${concentrator} / 호패 ${hopae} / 돌파 ${breakthrough}`}</span>
                      {(() => {
                        if (!sealMain && !sealSub) return null;
                        return (
                          <>
                            <div
                              style={{
                                width: "100%",
                                height: "1px",
                                background: "rgba(255,255,255,0.1)",
                                margin: "4px 0",
                              }}
                            ></div>
                            <span
                              className="naesil-btn-val small-text"
                              style={{ color: "var(--text-gold)" }}
                            >
                              {sealMain} / {sealSub}
                            </span>
                          </>
                        );
                      })()}
                    </>
                  ) : (
                    <span className="naesil-btn-val">미설정</span>
                  )}
                </div>
              </div>

              {/* 1-2. 스킬룬 */}
              <div
                className={`naesil-btn ${totalRunes > 0 ? "active" : ""}`}
                onClick={() => {
                  setEditBuffer(JSON.parse(JSON.stringify(userStats)));
                  setActiveModal({ type: "SKILL_RUNE", slot: null });
                }}
                style={{ height: "auto", minHeight: "60px", padding: "10px" }}
              >
                <img
                  src={`${IMAGE_BASE_URL}/icons/스킬룬.png`}
                  className="naesil-btn-img"
                  alt="룬"
                  onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                />
                <div className="naesil-btn-info">
                  <span
                    className="naesil-btn-label"
                    style={{ marginBottom: "4px" }}
                  >
                    스킬룬 ({totalRunes}/20)
                  </span>
                  <span
                    className="naesil-btn-val small-text"
                    style={{ lineHeight: "1.4" }}
                  >
                    {totalRunes > 0 ? runeSummaryText : "미설정"}
                  </span>
                </div>
              </div>

              {/* 1-3. 아바타 */}
              <div
                className={`naesil-btn ${avatarSet !== "없음" ? "active" : ""}`}
                onClick={() =>
                  setActiveModal({ type: "AVATAR_MAIN", slot: null })
                }
                style={{ height: "auto", minHeight: "60px", padding: "10px" }}
              >
                <img
                  src={`${IMAGE_BASE_URL}/icons/아바타.png`}
                  className="naesil-btn-img"
                  alt="압타"
                  onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                />
                <div className="naesil-btn-info">
                  <span
                    className="naesil-btn-label"
                    style={{ marginBottom: "4px" }}
                  >
                    아바타
                  </span>
                  <span className="naesil-btn-val small-text">
                    {avatarSet === "없음"
                      ? "미착용"
                      : formatTextWithLineBreak(avatarSet)}
                  </span>
                  {avatarSet !== "없음" && (
                    <div
                      style={{
                        width: "100%",
                        height: "1px",
                        background: "rgba(255,255,255,0.1)",
                        margin: "4px 0",
                      }}
                    ></div>
                  )}
                  <span
                    className="naesil-btn-val small-text"
                    style={{
                      color:
                        userStats.avatarSettings.weapon !== "없음"
                          ? "var(--text-gold)"
                          : "#888",
                    }}
                  >
                    {userStats.avatarSettings.weapon === "없음"
                      ? "무기압 X"
                      : formatTextWithLineBreak(
                          userStats.avatarSettings.weapon
                        )}
                  </span>
                </div>
              </div>

              {/* 1-4. 마스터 계약 */}
              <div
                className={`naesil-btn contract ${
                  userStats.training.masterContract ? "active" : ""
                }`}
                onClick={() =>
                  updateStat(
                    "training",
                    "masterContract",
                    !userStats.training.masterContract
                  )
                }
                style={{ height: "auto", minHeight: "60px", padding: "10px" }}
              >
                <img
                  src={`${IMAGE_BASE_URL}/icons/마스터계약.png`}
                  className="naesil-btn-img"
                  alt="계약"
                  onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                />
                <div className="naesil-btn-info">
                  <span className="naesil-btn-label">마스터 계약</span>
                  <span className="naesil-btn-val small-text">
                    {userStats.training.masterContract ? "적용 중" : "미적용"}
                  </span>
                </div>
              </div>
            </div>

            {/* 2. 스킬 설정 타이틀 (여기가 중요! 위에 중복된 '내실 설정' 없앰) */}
            <div className="panel-title" style={{ marginTop: "20px" }}>
              스킬 설정
            </div>

            <div className="naesil-control-box">
              <div
                className="naesil-btn"
                onClick={() => setActiveModal({ type: "SKILL_TREE" })}
              >
                <img
                  src={`${IMAGE_BASE_URL}/icons/스킬트리.png`}
                  className="naesil-btn-img"
                  alt="스킬"
                  onError={(e) => (e.target.src = PLACEHOLDER_IMG)}
                />
                <div className="naesil-btn-info">
                  <span className="naesil-btn-label">스킬트리</span>
                  <span
                    className="naesil-btn-val small-text"
                    style={{ color: "var(--text-gold)" }}
                  >
                    설정하기
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 2. 장비 컬럼 (좌) */}
          <div className="equip-column">
            {["머리어깨", "상의", "하의", "벨트", "신발"].map(
              renderGearSlotCard
            )}
          </div>

          {/* 3. 캐릭터 스테이지 (중앙) */}
          <div className="char-stage-center">
            <div className="char-control-bar">
              <button
                className="char-btn"
                onClick={() => setActiveModal({ type: "JOB_SELECTOR" })}
              >
                {userStats.character.baseJob || "직업군 선택"}
              </button>
              <button
                className="char-btn"
                style={{
                  opacity: userStats.character.baseJob ? 1 : 0.5,
                  cursor: userStats.character.baseJob
                    ? "pointer"
                    : "not-allowed",
                }}
                onClick={() =>
                  userStats.character.baseJob &&
                  setActiveModal({ type: "CLASS_SELECTOR" })
                }
              >
                {userStats.character.subJob || "전직 선택"}
              </button>
              {/* ★ [Update] 캐릭터 레벨 직관 입력창 (Input Field) */}
              {userStats.character.baseJob && (
                <div className="char-level-control">
                  <span className="char-level-title">LEVEL</span>
                  <input
                    type="number"
                    className={`char-level-input ${
                      isLevelShaking ? "shake-box" : ""
                    }`}
                    value={userStats.character.level || ""} // 0이나 빈값이면 비워둠
                    onChange={(e) => {
                      const valStr = e.target.value;

                      // 1. 다 지웠을 때 (빈칸 허용)
                      if (valStr === "") {
                        updateStat("character", "level", "");
                        return;
                      }

                      const val = Number(valStr);
                      const MAX_LV = 85; // 만렙 설정

                      // 2. 최대 레벨 초과 시 (흔들림 효과)
                      if (val > MAX_LV) {
                        setIsLevelShaking(true);
                        setTimeout(() => setIsLevelShaking(false), 300); // 0.3초 후 해제

                        // 강제로 만렙으로 고정
                        updateStat("character", "level", MAX_LV);
                        return;
                      }

                      // 3. 정상 입력
                      updateStat("character", "level", val);
                    }}
                    onBlur={(e) => {
                      // 포커스 나갈 때 비어있거나 0이면 기본값(1 or 85)으로 복구
                      if (!e.target.value || Number(e.target.value) <= 0) {
                        updateStat("character", "level", 85);
                      }
                    }}
                  />
                </div>
              )}
            </div>
            <div className="char-illust-box">
              {subJob && (
                <img
                  key={subJob}
                  src={`${IMAGE_BASE_URL}/characters/2ndillust/${subJob}.png`}
                  className="char-illust-img"
                  alt={subJob}
                  style={{ display: subJob ? "block" : "none" }}
                />
              )}
            </div>
            <div className="naesil-row">
              {["오라", "칭호", "크리쳐", "아티팩트"].map(renderGearSlotCard)}
            </div>
          </div>

          {/* 4. 장비 컬럼 (우) */}
          <div className="equip-column right">
            <div className="equip-group-vertical">
              {renderGearSlotCard("무기")}
              {["팔찌", "목걸이", "반지"].map(renderGearSlotCard)}
            </div>
            <div className="equip-group-vertical">
              {["보조장비", "마법석", "귀걸이"].map(renderGearSlotCard)}
            </div>
          </div>

          {/* ★ [New] 5. 우측 세트 효과 패널 */}
          <div className="set-effect-column">
            <div
              className="panel-title"
              style={{
                textAlign: "right",
                paddingRight: 5,
                paddingLeft: 0,
                borderLeft: "none",
                borderRight: "3px solid var(--text-gold)",
              }}
            >
              세트 효과
            </div>

            {/* 방어구 세트 (안전장치 ?. 추가) */}
            <div className="set-group-box">
              <div className="set-group-label">방어구</div>
              {/* activeSets?.armor?.length 로 수정하여 데이터가 없을 때를 대비 */}
              {activeSets?.armor?.length > 0 ? (
                activeSets.armor.map((set, i) => (
                  <div key={i} className="active-set-item">
                    {set.prefix && (
                      <span
                        className={`set-name-prefix ${
                          set.prefix === "각오" ? "prefix-pink" : "prefix-cyan"
                        }`}
                      >
                        [{set.prefix}]{" "}
                      </span>
                    )}
                    <span className="set-name-base">{set.name}</span>
                    <span
                      style={{
                        color: "var(--text-gold)",
                        fontSize: "0.7rem",
                        marginLeft: "4px",
                      }}
                    >
                      ({set.count})
                    </span>
                  </div>
                ))
              ) : (
                <div
                  style={{
                    textAlign: "center",
                    color: "#444",
                    fontSize: "0.8rem",
                  }}
                >
                  -
                </div>
              )}
            </div>

            {/* 장신구 세트 */}
            <div className="set-group-box">
              <div className="set-group-label">장신구</div>
              {activeSets?.accessory?.length > 0 ? (
                activeSets.accessory.map((set, i) => (
                  <div key={i} className="active-set-item">
                    {set.prefix && (
                      <span className="set-name-prefix prefix-cyan">
                        [{set.prefix}]{" "}
                      </span>
                    )}
                    <span className="set-name-base">{set.name}</span>
                    <span
                      style={{
                        color: "var(--text-gold)",
                        fontSize: "0.7rem",
                        marginLeft: "4px",
                      }}
                    >
                      ({set.count})
                    </span>
                  </div>
                ))
              ) : (
                <div
                  style={{
                    textAlign: "center",
                    color: "#444",
                    fontSize: "0.8rem",
                  }}
                >
                  -
                </div>
              )}
            </div>

            {/* 특수장비 세트 */}
            <div className="set-group-box">
              <div className="set-group-label">특수장비</div>
              {activeSets?.special?.length > 0 ? (
                activeSets.special.map((set, i) => (
                  <div key={i} className="active-set-item">
                    {set.prefix && (
                      <span className="set-name-prefix prefix-cyan">
                        [{set.prefix}]{" "}
                      </span>
                    )}
                    <span className="set-name-base">{set.name}</span>
                    <span
                      style={{
                        color: "var(--text-gold)",
                        fontSize: "0.7rem",
                        marginLeft: "4px",
                      }}
                    >
                      ({set.count})
                    </span>
                  </div>
                ))
              ) : (
                <div
                  style={{
                    textAlign: "center",
                    color: "#444",
                    fontSize: "0.8rem",
                  }}
                >
                  -
                </div>
              )}
            </div>
          </div>
        </div>{" "}
        {/* 상단 섹션 끝 */}
        {/* ★ [New] 하단 종합 능력치 패널 */}
        {renderBottomStatPanel()}
        {renderBottomSheet()}
      </div>
    );
  };

  const renderHome = () => (
    <div className="home-container">
      {/* 1. 히어로 배너 (Hero Banner) */}
      <div className="hero-banner">
        <div className="hero-title">MODAM</div>
        <div className="hero-subtitle">
          던전앤파이터 모바일의 모든 것을 담다.
          <br />
          가장 완벽한 데미지 계산 & 정보 포털
        </div>
        <button className="cta-button" onClick={() => setActivePage("CALC")}>
          데미지 계산기 시작하기
        </button>
      </div>

      {/* 2. 대시보드 그리드 */}
      <div className="dashboard-grid">
        {/* 카드 1: 공지사항 */}
        <div className="content-card">
          <div className="card-header">
            <div className="card-title">📢 공지사항</div>
            <span
              style={{ fontSize: "0.8rem", color: "#666", cursor: "pointer" }}
            >
              더보기 +
            </span>
          </div>
          <div className="notice-list">
            <div className="notice-item">
              <div>
                <span className="notice-tag">New</span> MODAM 사이트 오픈 안내
              </div>
              <span className="notice-date">12.06</span>
            </div>
            <div className="notice-item">
              <div>
                <span className="notice-tag">Patch</span> 신규 에픽 장비 데이터
                추가
              </div>
              <span className="notice-date">12.05</span>
            </div>
            <div className="notice-item">
              <div>
                <span>[점검]</span> 서버 안정화 작업 안내
              </div>
              <span className="notice-date">12.01</span>
            </div>
          </div>
        </div>

        {/* 카드 2: 유틸리티 메뉴 (바로가기) */}
        <div className="content-card">
          <div className="card-header">
            <div className="card-title">🛠️ 유틸리티</div>
          </div>
          <div className="menu-grid">
            <div className="menu-item" onClick={() => setActivePage("CALC")}>
              <span className="menu-icon">🧮</span>
              <span className="menu-label">계산기</span>
            </div>
            <div className="menu-item" onClick={() => alert("준비 중입니다!")}>
              <span className="menu-icon">📚</span>
              <span className="menu-label">아이템 도감</span>
            </div>
            <div className="menu-item" onClick={() => alert("준비 중입니다!")}>
              <span className="menu-icon">📊</span>
              <span className="menu-label">직업 랭킹</span>
            </div>
            <div className="menu-item" onClick={() => alert("준비 중입니다!")}>
              <span className="menu-icon">📝</span>
              <span className="menu-label">공략 게시판</span>
            </div>
          </div>
        </div>

        {/* 카드 3: 업데이트 예정 */}
        <div className="content-card">
          <div className="card-header">
            <div className="card-title">🚀 업데이트 예정</div>
          </div>
          <ul
            style={{
              color: "#aaa",
              paddingLeft: "20px",
              lineHeight: "1.8",
              fontSize: "0.9rem",
            }}
          >
            <li>스킬 계수표 최신화</li>
            <li>커스텀 칭호/오라 시뮬레이터</li>
            <li>길드 모집 게시판 기능</li>
            <li>모바일 환경 UI 최적화 (2차)</li>
          </ul>
        </div>
      </div>
    </div>
  );

  // 3. 데이터 로딩 중일 때 보여줄 화면 (스플래시 스크린)
  if (!isDataLoaded) {
    return (
      <div
        style={{
          height: "100vh",
          background: "#050505",
          color: "#ffcc00",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "20px",
        }}
      >
        <div style={{ fontSize: "2rem", fontWeight: "bold" }}>MODAM</div>
        <div>서버에서 최신 데이터를 불러오고 있습니다...</div>
        {/* 여기에 로딩바 애니메이션 등을 넣으면 더 좋음 */}
      </div>
    );
  }

  return (
    <div
      style={{
        backgroundColor: "#0d0d0d",
        minHeight: "100vh",
        color: "#dcdcdc",
      }}
    >
      {renderInnerModal()}
      <header className="site-header">
        <div className="logo-area" onClick={() => setActivePage("HOME")}>
          <span style={{ color: "#ffcc00" }}>MODAM</span>
        </div>
        <nav className="gnb-menu">
          <div
            className={`gnb-item ${activePage === "HOME" ? "active" : ""}`}
            onClick={() => setActivePage("HOME")}
          >
            홈
          </div>
          <div
            className={`gnb-item ${activePage === "CALC" ? "active" : ""}`}
            onClick={() => setActivePage("CALC")}
          >
            데미지 계산기
          </div>
        </nav>
        <div style={{ width: "40px" }}></div>
      </header>
      <main>
        {activePage === "HOME" && renderHome()}
        {activePage === "CALC" && renderCalculatorPage()}
      </main>
    </div>
  );
}
