const API_URL =
  "https://script.google.com/macros/s/AKfycbxsgzY_MLNrCY9cUrG3nn5-1_5H4DcPvjVHaJSZZWWHFapEO2mIKS7ThL0tCip8ij5dZg/exec";

// ---------------------------------------------------------
// [1] 무기 데이터베이스 (WEAPON_DB)
// ---------------------------------------------------------
export let WEAPON_DB = [];

// ---------------------------------------------------------
// [2] 방어구/악세/특장 데이터베이스 (GEAR_DB)
// ---------------------------------------------------------
export let GEAR_DB = [];

// =============================================================================
// [3] 강화/연마 데이터 테이블 (REINFORCE_DB / POLISH_DB)
// =============================================================================
export let REINFORCE_DB = {},
  POLISH_DB = {};

// =============================================================================
// [4] 마법봉인 옵션 데이터 (부위별 그룹화)
// =============================================================================
export let MAGIC_OPTS_BY_GROUP = {};

// =============================================================================
// [5] 마법부여 데이터 (부위별 개별 리스트)
// =============================================================================
export let ENCHANT_LIST_BY_SLOT = {};

// =============================================================================
// [6] 엠블렘 데이터
// =============================================================================
export let EMBLEM_DB = {
  Red: { stats: {} },
  Yellow: { stats: {} },
  Green: { stats: {} },
  Blue: { stats: {} },
  Platinum: { options: [] },
};

export const EMBLEM_RULES = {
  머리어깨: { slots: 2, types: ["Yellow"] },
  상의: { slots: 2, types: ["Red"] },
  하의: { slots: 2, types: ["Red"] },
  벨트: { slots: 2, types: ["Yellow"] },
  신발: { slots: 2, types: ["Blue"] },
  팔찌: { slots: 2, types: ["Blue"] },
  목걸이: { slots: 2, types: ["Green"] },
  반지: { slots: 2, types: ["Green"] },
  무기: { slots: 2, types: ["Red", "Yellow", "Green", "Blue"] }, // 무기는 다 됨
  보조장비: { slots: 1, types: ["Platinum"] },
  마법석: { slots: 1, types: ["Platinum"] },
  귀걸이: { slots: 1, types: ["Platinum"] },
  칭호: { slots: 1, types: ["Platinum"] },
  오라: { slots: 0, types: [] },
  크리쳐: { slots: 0, types: [] },
  아티팩트: { slots: 0, types: [] },
};

// =============================================================================
// [7] 내실 데이터 (수련일지 / 아바타 / 성안의 봉인)
// =============================================================================

// 1. 수련 일지 (레벨별 누적 스탯)
export let TRAINING_DB = {};

// 2. 아바타 세트 효과
export let AVATAR_DB = {},
  WEAPON_AVATAR_DB = [];

// =============================================================================
// [8] 스킬 데이터
// =============================================================================
export let SKILL_DB = [];

// =============================================================================
// [9] 스킬룬 설정 데이터
// =============================================================================

export const RUNE_CONSTANTS = {
  // 1. 특수 스킬룬 (4레벨 고정)
  special: {
    max: { gaho: 2, jihe: 2, waegok: 1 },
    synergyJobs: ["와일드베인", "윈드시어"], // 1개만 껴도 효과 보는 직업

    options: {
      gaho: { allEle: 15 }, // 가호 효과
      jihe: { allEle: 15 }, // 지혜 효과
      waegok: {}, // 왜곡 효과
    },

    list: [
      {
        id: "gaho",
        name: "가호의 룬",
        grade: 4,
        type: "special",
        stats: { allEle: 15 },
      },
      {
        id: "jihe",
        name: "지혜의 룬",
        grade: 4,
        type: "special",
        stats: { allEle: 15 },
      },
      { id: "waegok", name: "왜곡의 룬", grade: 4, type: "special", stats: {} }, // 쿨초 기능은 추후 구현
    ],
  },

  // 2. 일반 스킬룬 (3, 4레벨)
  general: {
    types: ["각성", "파멸", "마력", "재물"],
    grades: [3, 4],
    levels: {
      각성: [15, 20, 25, 30, 35, 40, 45, 65],
      파멸: [15, 20, 25, 30, 35, 40, 45, 65],
      마력: [15, 20, 25, 30, 35, 40, 45, 65],
      재물: [15, 20, 25, 30],
    },
    // 종류 & 등급별 스증 수치 (%) -> 계산 로직에서 참조
    values: {
      각성: { 3: 3, 4: 4 },
      파멸: { 3: 3, 4: 4 },
      마력: { 3: 2, 4: 3 },
      재물: { 3: 2, 4: 3 },
    },
  },
};

// ---------------------------------------------------------
// [3] 고유 옵션 설명 데이터
// ---------------------------------------------------------
export const UNIQUE_OPT_DESC = {
  "선택 안함": "",
  // 무기
  광채: "공격 시 5% 확률로 광채 폭발 발생\n(모든 속성 강화 +20)",
  분쇄: "카운터 공격 시 데미지 20% 증가\n(추가 데미지 +15%)",
  선명: "모든 속성 강화 +20\n스킬 공격력 5% 증가",
  강타: "물리/마법 공격력 15% 증가\n힘/지능 5% 증가",
  // 방어구/악세/특장 (익시드)
  이상: "상태이상 데미지 10% 증가\n상태이상 내성 무시 5%",
  선봉: "대시 공격 시 슈퍼아머 생성\n이동속도 +10%, 데미지 증가 7%",
  의지: "피격 시 받는 데미지 10% 감소\nHP MAX +500, 스킬 공격력 5%",
};

// ---------------------------------------------------------
// [5] 직업별 기본 패시브 (1레벨 기준 샘플)
// ---------------------------------------------------------
export const JOB_PASSIVES = {
  웨펀마스터: { physCrit: 10, skillAtk: 20 },
  소울브링어: { magCrit: 10, darkEle: 20, skillAtk: 15 },
  버서커: { physCrit: 15, str: 200, skillAtk: 18 },
  아수라: { magCrit: 15, int: 200, skillAtk: 18 },
  소드마스터: { physCrit: 10, skillAtk: 20 },
  다크템플러: { magCrit: 10, skillAtk: 20 },
  데몬슬레이어: { physCrit: 10, skillAtk: 22 },
  베가본드: { physCrit: 10, skillAtk: 20, str: 100 },
  블레이드: { physCrit: 12, skillAtk: 21 },
  넨마스터: { magCrit: 10, lightEle: 20, skillAtk: 20 },
  스트라이커: { physCrit: 10, skillAtk: 20 },
  레인저: { physCrit: 20, physCritDmg: 10 },
  런처: { physCrit: 10, skillAtk: 20 },
  메카닉: { magCrit: 15, int: 150, skillAtk: 20 },
  스핏파이어: { physCrit: 10, magCrit: 10, skillAtk: 20 },
  엘레멘탈마스터: { magCrit: 5, allEle: 20, skillAtk: 20 },
  배틀메이지: { physCrit: 10, magCrit: 10, skillAtk: 20 },
  마도학자: { magCrit: 10, skillAtk: 20, allEle: 15 },
  인챈트리스: { magCrit: 10, int: 300, skillAtk: 15 },
  크루세이더: { magCrit: 10, int: 200, skillAtk: 10 },
  인파이터: { physCrit: 10, skillAtk: 20 },
  미스트리스: { magCrit: 10, skillAtk: 20 },
  이단심판관: { physCrit: 10, skillAtk: 20 },
  무녀: { magCrit: 10, skillAtk: 20 },
  와일드베인: { physCrit: 10, skillAtk: 20 },
  윈드시어: { magCrit: 10, skillAtk: 20 },
  로그: { physCrit: 20, physCritDmg: 15 },
  쿠노이치: { magCrit: 10, fireEle: 30, skillAtk: 15 },
  뱅가드: { physCrit: 10, skillAtk: 20 },
  다크랜서: { magCrit: 10, darkEle: 20, skillAtk: 20 },
};

export let GEAR_POINT_BONUS_DB = { armor: [], accessory: [], special: [] };

// ---------------------------------------------------------
// [2] 데이터 로딩 함수 (비동기)
// ---------------------------------------------------------
export const loadGameData = async () => {
  try {
    const response = await fetch(API_URL);
    const data = await response.json();

    // --- [1] 장비 (기존 동일) ---
    WEAPON_DB = data.weapons || [];
    GEAR_DB = [
      ...(data.armors || []),
      ...(data.accessories || []),
      ...(data.special || []),
      ...(data.sets || []),
      ...(data.auras || []),
      ...(data.titles || []),
      ...(data.creatures || []),
      ...(data.artifacts || []),
    ];

    // --- [2] 강화/연마/수련 (Level-based 변환) ---
    // 시트 데이터: [{type: '무기', level: 10, stats: {...}}, ...]
    // 목표 구조: { 무기: { 10: {...}, 11: {...} } }
    const transformLevelDB = (rows) => {
      const result = {};
      rows.forEach((row) => {
        const key = row.type || row.slot; // 시트 헤더에 따라 type 또는 slot 사용
        if (!result[key]) result[key] = {};
        result[key][row.level] = row.stats;
      });
      return result;
    };

    REINFORCE_DB = transformLevelDB(data.reinforce || []);
    POLISH_DB = transformLevelDB(data.polish || []);

    // 수련일지는 type이 'concentrator'(마력), 'hopae'(호패) 등으로 구분됨
    TRAINING_DB = transformLevelDB(data.training || []);
    const castleRows = data.castleSeal || [];

    // 1. 빈 구조 생성
    TRAINING_DB.castle_seal = {
      base: { stats: {} },
      main: [],
      sub: [],
    };

    // 2. 분류 작업
    castleRows.forEach((row) => {
      const group = row.group; // 'base', 'main', 'sub'

      if (group === "base") {
        // base는 리스트가 아니라 단일 객체이므로 덮어쓰기 (또는 stats 합치기)
        TRAINING_DB.castle_seal.base = row;
      } else if (group === "main") {
        // main 옵션 목록에 추가
        TRAINING_DB.castle_seal.main.push(row);
      } else if (group === "sub") {
        // sub 옵션 목록에 추가
        TRAINING_DB.castle_seal.sub.push(row);
      }
    });

    // --- [3] 마법봉인 (Group-based 변환) ---
    // 목표: { 무기: { unique: [], common: [] } }
    MAGIC_OPTS_BY_GROUP = {};
    (data.magicOpts || []).forEach((row) => {
      const group = row.group; // '무기', '방어구' ...
      if (!MAGIC_OPTS_BY_GROUP[group]) {
        MAGIC_OPTS_BY_GROUP[group] = { unique: [], common: [] };
      }
      // 시트에 isUnique 컬럼(TRUE/FALSE)이 있다고 가정
      if (row.isUnique === true || row.isUnique === "TRUE") {
        MAGIC_OPTS_BY_GROUP[group].unique.push(row);
      } else {
        MAGIC_OPTS_BY_GROUP[group].common.push(row);
      }
    });

    // --- [4] 마법부여 (List-based 변환) ---
    // 목표: { 무기: [옵션1, 옵션2], 상의: [...] }
    ENCHANT_LIST_BY_SLOT = {};
    (data.enchants || []).forEach((row) => {
      const slot = row.slot || row.group; // '무기', '상의' ...
      if (!ENCHANT_LIST_BY_SLOT[slot]) ENCHANT_LIST_BY_SLOT[slot] = [];
      ENCHANT_LIST_BY_SLOT[slot].push(row);
    });

    // --- [5] 엠블렘 (구조체 변환) ---
    // 목표: EMBLEM_DB 구조 (Red, Yellow... Platinum)
    EMBLEM_DB = {
      Red: { name: "붉은빛", img: "red", stats: {} },
      Yellow: { name: "노란빛", img: "yellow", stats: {} },
      Green: { name: "녹색빛", img: "green", stats: {} },
      Blue: { name: "푸른빛", img: "blue", stats: {} },
      Platinum: { options: [] },
    };

    const emRows = data.emblems || [];

    emRows.forEach((row) => {
      // 시트 헤더: type, options, name, level, img, stats_...
      const type = row.type; // Red, Platinum ...

      if (type === "Platinum") {
        // 플래티넘은 options 배열에 통째로 넣음
        // (App.js가 options 배열을 순회하며 그림)
        EMBLEM_DB.Platinum.options.push({
          id: row.options || row.name, // id로 쓸만한 것
          name: row.name,
          img: row.img,
          stats: row.stats, // stats_str 등으로 파싱된 객체
        });
      } else if (EMBLEM_DB[type]) {
        // 일반 엠블렘 (Red, Yellow 등)
        // 목표 구조: EMBLEM_DB.Red.stats.str.1 = 10

        const statsObj = row.stats || {};
        const lv = row.level;

        // stats 객체를 순회하며 구조 맞추기
        Object.keys(statsObj).forEach((statKey) => {
          if (!EMBLEM_DB[type].stats[statKey]) {
            EMBLEM_DB[type].stats[statKey] = {};
          }
          // 레벨별 수치 할당
          EMBLEM_DB[type].stats[statKey][lv] = statsObj[statKey];
        });
      }
    });

    const gpRows = data.gearPointBonus || [];

    // 초기화
    GEAR_POINT_BONUS_DB = { armor: [], accessory: [], special: [] };

    gpRows.forEach((row) => {
      const type = row.type; // 'armor', 'accessory', 'special'

      // 유효한 타입인 경우에만 푸시
      if (GEAR_POINT_BONUS_DB[type]) {
        GEAR_POINT_BONUS_DB[type].push({
          threshold: Number(row.threshold), // 숫자로 확실하게 변환
          stats: row.stats || {},
        });
      }
    });

    const rawSkills = data.skills || [];

    SKILL_DB = rawSkills.map((row) => {
      // ★ [중요] maxLv 변수를 반드시 return 문 "위"에서 먼저 선언해야 합니다!
      // 그래야 아래쪽 limitLv 계산식인 (maxLv + 10)에서 사용할 수 있습니다.
      const maxLv = Number(row.maxLv || row.max_lv || row["마스터레벨"] || 50);

      return {
        id: row.id || row.ID || `SK_${Math.random().toString(36).substr(2, 9)}`,

        // 직업/이름
        jobGroup: row.jobGroup || row.job_group || row["직업군"] || "",
        jobName: row.jobName || row.job_name || row["전직"] || "공용",
        name: row.name || row["스킬명"] || "이름없음",

        // 레벨링 정보
        rowIndex: Number(row.rowIndex || row.row_index || 1),
        startLv: Number(row.startLv || row.start_lv || 1),
        levelStep: Number(row.levelStep || row.level_step || 2),
        minLv: Number(row.minLv || row.min_lv || 0),

        // ★ 위에서 만든 변수 사용
        maxLv: maxLv,
        // ★ 여기서 maxLv 변수를 사용하므로 선언 순서가 중요함
        limitLv: Number(row.limitLv || maxLv + 10),

        // 비용
        spCost: Number(row.spCost || row.sp_cost || row.sp || 0),
        tpCost: Number(row.tpCost || row.tp_cost || row.tp || 0),

        // 상세 스펙
        cooltime: Number(row.cooltime || 0),
        type: row.type || "active",

        dmgBase: Number(row.dmgBase || 0),
        dmgGrowth: Number(row.dmgGrowth || 0),
        tpGrowth: Number(row.tpGrowth || 0),

        category: row.category || row.Category || "normal",

        img: row.img || row.image || "",
      };
    });

    console.log("✅ 모든 데이터 로드 완료!");
    return true;
  } catch (error) {
    console.error("❌ 로드 실패:", error);
    return false;
  }
};

// ---------------------------------------------------------
// [6] 이미지/아이콘 헬퍼 (기존 유지)
// ---------------------------------------------------------
const IMAGE_BASE_URL =
  "https://raw.githubusercontent.com/tigerexist1528/modam-assets/main/images";

//로고 이미지 경로
export const PLACEHOLDER_IMG = `${IMAGE_BASE_URL}/MODAM.png`;

const SLOT_FOLDER_MAP = {
  // [무기]
  무기: "weapon",

  // [방어구]
  머리어깨: "headshoulder",
  상의: "top",
  하의: "bottom",
  벨트: "belt",
  신발: "shoes",

  // [악세서리]
  팔찌: "bracelet",
  목걸이: "necklace",
  반지: "ring",

  // [특수장비]
  보조장비: "sub",
  마법석: "magestone",
  귀걸이: "earring",

  // [스페셜 장비] (새로 추가하신 폴더들)
  오라: "aura",
  칭호: "title",
  크리쳐: "creature",
  아티팩트: "artifact",
};

// 아이콘 경로 생성 함수 (작성하신 코드 + 안전장치)
export const GET_ITEM_ICON = (name, slot) => {
  if (!name || !slot) return PLACEHOLDER_IMG;

  let cleanName = name;

  // ★ 수정: "무기"가 아닐 때만 콜론(:) 뒤의 텍스트를 사용
  // (방어구/악세 등은 "에픽 : 이름" -> "이름"으로 변환)
  // (무기는 "뇌검 : 고룬" -> "뇌검 : 고룬" 원본 유지)
  if (slot !== "무기" && name.includes(":")) {
    cleanName = name.split(":")[1].trim();
  }

  // ※ 주의: 만약 서버 파일명에 콜론(:)을 쓸 수 없다면
  // 아래 주석을 풀어서 콜론을 제거하거나 공백으로 바꿔주세요.
  // cleanName = cleanName.replace(/:/g, "");

  const folder = SLOT_FOLDER_MAP[slot] || "etc";
  return `${IMAGE_BASE_URL}/items/${folder}/${cleanName}.png`;
};

export const GET_JOB_ICON = (type, name) => {
  if (!type || !name) return PLACEHOLDER_IMG;

  // 파일명에서 특수문자 제거 (예: "귀검사(남)" -> "귀검사남") - 필요 시 주석 해제
  // const cleanName = name.replace(/[()]/g, "");
  // return `/images/characters/${type}/${cleanName}.png`;

  // 우선은 제공해주신 이름 그대로 사용 (파일명을 맞춰주세요: "귀검사(남).png")
  return `${IMAGE_BASE_URL}/characters/${type}/${name}.png`;
};
